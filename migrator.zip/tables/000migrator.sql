## Created using Migrator 1.3 for Joomla! 1.0
#
# Migrator SQL Plugin
#
# These files are designed to have SQL CREATE TABLE statements
# so that tables are created for data migration.
# 
