<?php
/**
 * @version		1.5.3.47 views/categories/view.raw.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3beta5.43
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.application.component.view');

require_once (JPATH_COMPONENT.DS.'helpers'.DS.'exporter.php');
require_once (JPATH_COMPONENT.DS.'helpers'.DS.'version.php');

/**
 * J2XML Component Categories View
 */
class J2XMLViewCategories extends JView
{
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		$cid = JRequest::getVar('cid');		
		$ids = explode(",", $cid);

		$params =& JComponentHelper::getParams('com_j2xml');
		$images = array();

		$xml = J2XMLExporter::categories($ids,
					$params->get('export_images', '1'),
					1,
					$params->get('export_users', '1'),
					$images
				);
		foreach ($images as $image)
			$xml .= $image;	
		
		if (!J2XMLExporter::export(
				$xml,		
				$params->get('debug', 0), 
				$params->get('export_gzip', '0')
			))
			$app->redirect('index.php?option=com_categories&section=com_content');
	}
}
?>