<?php
/**
 * @version		1.5.4.72 views/websites/tmpl/default.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @version		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010-2013 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

JHTML::_('behavior.tooltip');
?>
<form action="index.php" method="post" name="adminForm">
<table>
<tr>
	<td align="left" width="100%">
		<?php echo JText::_('Filter'); ?>:
		<input type="text" name="<?php echo $this->prefix; ?>search" id="<?php echo $this->prefix; ?>search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
		<button onclick="this.form.submit();"><?php echo JText::_('Go'); ?></button>
		<button onclick="document.getElementById('<?php echo $this->prefix; ?>search').value='';
			this.form.getElementById('<?php echo $this->prefix; ?>filter_state').value='';
			this.form.submit();"><?php echo JText::_('Reset'); ?></button>
	</td>
	<td nowrap="nowrap">
		<?php
			echo $this->lists['state'];
		?>
	</td>
</tr>
</table>
<div id="editcell">

<table class="adminlist">
<?php $columns = 8; ?>
<thead>
	<tr>
		<th width="1%" nowrap="nowrap"><?php echo JText::_('NUM'); ?></th>
		<th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" /></th>
		<th class="title">
			<?php echo JHTML::_('grid.sort', 'Title', 'a.title', $this->lists['order_Dir'], $this->lists['order']); ?>
		</th>
		<th class="title">
			<?php echo JHTML::_('grid.sort', 'Remote_URL', 'a.remote_url', $this->lists['order_Dir'], $this->lists['order']); ?>
		</th>
		<th width="5%" nowrap="nowrap">
			<?php echo JHTML::_('grid.sort', 'Version', 'a.version', $this->lists['order_Dir'], $this->lists['order']); ?>
		</th>
		<th width="25%" nowrap="nowrap">
			<?php echo JHTML::_('grid.sort', 'Username', 'a.username', $this->lists['order_Dir'], $this->lists['order'] ); ?>
		</th>
		<th width="5%" nowrap="nowrap">
			<?php echo JHTML::_('grid.sort', 'Published', 'a.published', $this->lists['order_Dir'], $this->lists['order'] ); ?>
		</th>
		<th width="1%" class="title">
			<?php echo JHTML::_('grid.sort', 'ID', 'a.id', $this->lists['order_Dir'], $this->lists['order']); ?>
		</th>
	</tr>
</thead>
<tbody>
<?php
if (count($this->items) == 0) {
?>
	<tr><td colspan="<?php echo $columns; ?>"><?php echo JText::_('COM_J2XML_MSG_THERE_ARE_NO_WEBSITES'); ?></td></tr>
<?php
} else {
	$J2XMLVersions = array('1.5', '1.6', '2.5+');
	$k = 0;
	for ($i=0, $n=count($this->items); $i<$n; $i++)
	{
		$row =& $this->items[$i];
/*
		$user = & JFactory::getUser();
		if ($user->authorize('com_users', 'manage')) {
			if ($row->created_by_alias) {
				$author = $row->created_by_alias;
			} else {
				$linkA 	= 'index.php?option=com_users&task=edit&cid[]='. $row->created_by;
				$author = '<a href="'. JRoute::_($linkA) .'" title="'. JText::_('Edit User') .'">'. $row->editor .'</a>';
			}
		} else {
			if ($row->created_by_alias) {
				$author = $row->created_by_alias;
			} else {
				$author = $row->editor;
			}
		}
*/
		$checked = JHTML::_('grid.checkedout', $row, $i);
		$published = JHTML::_('grid.published', $row, $i );
/*
		$access = JHTML::_('grid.access', $row, $i);
		$cat_link = JRoute::_('index.php?option=com_categories&task=edit&cid[]='.$row->catid);
		$created = $row->created;
*/
		?>
	<tr class="<?php echo "row$k" ?>">
		<td><?php echo $this->pagination->getRowOffset($i); ?></td>
		<td><?php echo $checked; ?></td>
		<td>
			<?php
			$user =& JFactory::getUser();
			if (JTable::isCheckedOut($user->get('id'), $row->checked_out)) {
				echo $row->title;
			} else { ?>
			<span class="editlinktip hasTip" title="<?php echo JText::_('Edit'); ?>::<?php echo $row->title; ?>">
			<?php echo JHTML::link(
					'index.php?option=com_j2xml&task=website.edit&cid[]='.$row->id, 
					$row->title
					);
			?>
			</span>
			<?php } ?>
		</td> 		
		<td><?php echo $row->remote_url;?></td>		
		<td align="center"><?php echo $J2XMLVersions[$row->version];?></td>		
		<td align="center"><?php echo $row->username;?></td>		
		<td align="center"><?php echo $published;?></td>
		<td><?php echo $row->id; ?></td>
	</tr>
<?php
	  $k = 1 - $k;
	}
}
?>
</tbody>
<tfoot>
	<tr>
		<td colspan="<?php echo $columns; ?>">
			<?php echo $this->pagination->getListFooter(); ?>
		</td>
	</tr>
</tfoot>
</table>
</div>
	<input type="hidden" name="option" value="com_j2xml" />
	<input type="hidden" name="c" value="website" />
	<input type="hidden" name="view" value="websites" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
	<?php echo JHTML::_('form.token'); ?>
</form>
