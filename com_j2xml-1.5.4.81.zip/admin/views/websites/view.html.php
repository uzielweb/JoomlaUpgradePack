<?php
/**
 * @version		1.5.3.47 views/websites/view.html.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @version		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.application.component.view');
require_once(JPATH_COMPONENT.DS.'helpers'.DS.'grid2.php');

class J2XMLViewWebsites extends JView
{
	function display($tmpl = null)
	{
		$app =& JFactory::getApplication('administrator');
		// Get data from the model
		$items = & $this->get('Data');
		$this->assignRef('items', $items);

		// Get pagination from the model
		$pagination = & $this->get('Pagination');
		$this->assignRef('pagination', $pagination);
		$total = & $this->get('Total');
		$this->assignRef('total', $total);
		
		$context			= 'com_j2xml.website.list.';
		$prefix				= 'com_j2xml_website_list_';
		$filter_order		= $app->getUserStateFromRequest('filter_order',		'filter_order',		'c.title',	'cmd' );
		$filter_order_Dir	= $app->getUserStateFromRequest('filter_order_Dir',	'filter_order_Dir',	'',			'word' );
		
		$search				= $app->getUserStateFromRequest($context.'search',			$prefix.'search',			'',			'string' );
		if (strpos($search, '"') !== false) {
			$search = str_replace(array('=', '<'), '', $search);
		}
		$search = JString::strtolower($search);

		$limit		= $app->getUserStateFromRequest('global.list.limit',	'limit',		$app->getCfg('list_limit'),	'int');
		$limitstart = $app->getUserStateFromRequest($context.'limitstart',	'limitstart',	0,							'int');
				
		//get list of state for dropdown menu
		$lists['state'] = '<input type="hidden" id="'.$prefix.'filter_state" value="P" />'; 

		$lists['search']= $search;
		
		// table ordering
		$lists['order_Dir'] = $filter_order_Dir;
		$lists['order'] = $filter_order;
		
		$this->assignRef('lists', $lists);

		$this->assignRef('prefix', $prefix);
		
		parent::display($tmpl);
	}
}
?>
