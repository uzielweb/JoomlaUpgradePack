<?php
/**
 * @version		1.5.4.71 views/cpanel/tmpl/default.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');
JHTML::_('behavior.tooltip');
jimport('joomla.language.language');
require_once (JPATH_COMPONENT.DS.'helpers'.DS.'version.php');

?>
<table width='100%'>
    <tr>
        <td width='55%' class='adminform' valign='top'>
		<div id='cpanel'>
		<?php 
		$link = 'index.php?option=com_content';
		$this->_quickiconButton($link, 'icon-48-article.png', JText::_('COM_J2XML_TOOLBAR_ARTICLE_MANAGER'));
		
		$link = 'index.php?option=com_j2xml&amp;view=websites';
		$this->_quickiconButton($link, 'icon-48-websites.png', JText::_('COM_J2XML_TOOLBAR_WEBSITE_MANAGER'), 'components/com_j2xml/assets/images/header/');

		$link = 'index.php?option=com_j2xml&amp;task=sections.display&format=raw&contents=false';
		$this->_quickiconButton($link, 'icon-48-category.png', JText::_('COM_J2XML_TOOLBAR_EXPORT_STRUCTURE'));

		$link = 'index.php?option=com_j2xml&amp;task=users.display&format=raw';
		$this->_quickiconButton($link, 'icon-48-user.png', JText::_('COM_J2XML_TOOLBAR_EXPORT_USERS'));

		$db = JFactory::getDBO();
		$query = "SELECT count(*) FROM #__content";
		$db->setQuery( $query );
		$n = $db->loadResult();
		
		$params = JComponentHelper::getParams('com_j2xml');
		$d = $params->get('export_blocksize', 1000);
		
		for ($i = 0, $j = 1; $i < $n; $i += $d, $j++)
		{
			$link = "index.php?option=com_j2xml&amp;task=content.display&format=raw&limit={$i},{$d}";
			$this->_quickiconButton($link, 'icon-48-content.png', sprintf(JText::_('COM_J2XML_TOOLBAR_EXPORT_PAGE'),$j));
		}
		
		?>
		</div>
        <div class='clr'></div>
        </td>
		<td valign='top' width='45%' style='padding: 7px 0 0 5px'>
			<?php
			echo $this->pane->startPane('pane');
			
			$title = JText::_('Welcome_to_J2XML');
			echo $this->pane->startPanel($title, 'welcome');
			?>
			<table class='adminlist'>
			<tr>
				<td colspan='2'>
					<p><?php echo JText::_('COM_J2XML_DESCRIPTION')?></p>
				</td>
<?php 
JHTML::_('behavior.mootools');

$latest = (JPluginHelper::isEnabled('system', 'mtupgrade'));
?>
				<td rowspan='<?php echo $latest ? '5' : '4'?>' style="text-align:center">
					<a href='http://www.eshiol.it/j2xml.html'>
					<img src='components/com_j2xml/assets/images/j2xml.png' width='110' height='110' alt='J2XML' title='J2XML' align='middle' border='0'>
					</a>
				</td>
			</tr>
			<tr>
				<td width='25%'>
					<?php echo JText::_('Installed_Version'); ?>
				</td>
				<td width='45%'>
					<?php  echo J2XMLVersion::getLongVersion(); ?>
				</td>
			</tr>
<?php 
if ($latest) :
?>
			<tr>
				<td width='25%'>
					<?php echo JText::_('Latest_Version'); ?>
				</td>
				<td width='45%'>
<!-- 
<script type="text/javascript" language="javascript">
	var updateKeyRef = 'com_j2xml_1503'; 
	var updateLink = '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_CHECK')); ?>';	
	var updateComponentVersion = '<?php echo J2XMLVersion::getFullVersion();?>';

	var msgChecking4Updates = '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_CHECKING')); ?>';
	var msgDownload = '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_DOWNLOAD')); ?>';
	var msgFailed2Check = '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_FAILED')); ?>';
	var msgLatestInstalled = '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_LATEST')); ?>';
	var msgNewerAvailable = '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_NEWER')); ?>';
	var msgUpdate = '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_NOW')); ?>';
</script>
 -->
<?php 
	$doc =& JFactory::getDocument();
	$doc->addScript('components/com_j2xml/assets/js/update.js');
	$doc->addScript('components/com_j2xml/assets/js/version_compare.js');
	$doc->addScript('components/com_j2xml/assets/js/xmlrpc.js');
?>
<div style="float:left" id="update">
	<span id="update-response"></span>
	<a href="#" id="update-link"><?php echo JText::_('COM_J2XML_LIVEUPDATE_CHECK'); ?></a>
	<input type="hidden" name="install_url" value="" />
	<input type="hidden" name="installtype" value="url" />
</div>
<script type="text/javascript" language="javascript">
window.addEvent('domready', function() {
	ExtensionUpdater.initialize('update-link', 'update-response');
	ExtensionUpdater.set('keyref', 'com_j2xml'); 
	ExtensionUpdater.set('version', '<?php echo J2XMLVersion::getFullVersion();?>');
	ExtensionUpdater.set('url', 'http://www.eshiol.it/xmlrpc/index.php');
	ExtensionUpdater.set('msgChecking4Updates', '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_CHECKING')); ?>');
	ExtensionUpdater.set('msgDownload', '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_DOWNLOAD')); ?>');
	ExtensionUpdater.set('msgFailed2Check', '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_FAILED')); ?><br/>');
	ExtensionUpdater.set('msgLatestInstalled', '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_LATEST')); ?>');
	ExtensionUpdater.set('msgNewerAvailable', '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_NEWER')); ?>');
	ExtensionUpdater.set('msgUpdate', '<?php echo str_replace('\'', '\\\'', JText::_('COM_J2XML_LIVEUPDATE_NOW')); ?>');
	ExtensionUpdater.set('auth', '<?php echo ($this->params->getValue('liveupdate_username').$this->params->getValue('liveupdate_password')) ? base64_encode($this->params->getValue('liveupdate_username').':'.$this->params->getValue('liveupdate_password')) : ''; ?>');
});
</script>
				</td>
			</tr>
<?php endif; ?>
			<tr>
				<td>
					<?php echo JText::_('Copyright'); ?>
				</td>
				<td>
					<a href='http://www.eshiol.it' target='_blank'>&copy; 2010-2013 Helios Ciancio <img src='components/com_j2xml/assets/images/eshiol.png' alt='eshiol.it' title='eshiol.it' border='0'></a>
				</td>
			</tr>
			<tr>
				<td>
					<?php echo JText::_('License'); ?>
				</td>
				<td>
					<a href='http://www.gnu.org/licenses/gpl-3.0.html' target='_blank'>GNU GPL v3</a>
				</td>
			</tr>
			</table>
			<?php
			echo $this->pane->endPanel();

			$title = JText::_('State');
			echo $this->pane->startPanel($title, 'state');
			?>
			<table class='adminlist'>
				<thead>
				<tr>
					<td class="title"><strong><?php echo JText::_('Name'); ?></strong></td>
					<td class="title"><strong><?php echo JText::_('Type'); ?></strong></td>
					<td class="title"><strong><?php echo JText::_('Group'); ?></strong></td>
					<td class="title"><strong><?php echo JText::_('Version'); ?></strong></td>
					<td class="title"><strong><?php echo JText::_('State'); ?></strong></td>
				</tr>
				</thead>
				<tbody>
			<?php 
				for ($i = 0; $i < count($this->info['extensions']); $i++)
				{
					$ext = $this->info['extensions'][$i];
					echo '<tr>';
					if ($ext['type']=='plugin')
						if ($ext['state'] == 'not installed')
							echo '<td>'.$ext['name'].'</td>';
						else
						{
							echo '<td><span class="editlinktip hasTip" title="'.JText::_('Edit Plugin').'::'.$ext['name'].'">';
							echo '<a href="index.php?option=com_plugins&view=plugin&client=site&task=edit&cid[]='.$ext['id'].'">'.$ext['name'].'</a>';
							echo '</span></td>';
						}
					else if ($ext['type']=='configuration')
						echo '<td>
							<span class="editlinktip hasTip" title="'.JText::_('Edit Configuration').'::'.$ext['name'].'"> 
							<a href="index.php?option=com_config">'.$ext['name'].'</a>
							</span>
							</td>';
					else
					echo '<td>'.$ext['name'].'</td>';			
					echo '<td>'.$ext['type'].'</td>';
					echo '<td>'.$ext['group'].'</td>';
					echo '<td>'.$ext['version'].'</td>';
					echo '<td style="text-align:center;"><img src="components/com_j2xml/assets/images/'.$ext['state'].'.png" /></td>';
					echo '</tr>';
				}
			?>
				</tbody>
			</table>
			<?php 
			echo $this->pane->endPanel();
			
			$title = JText::_('Support_us');
			echo $this->pane->startPanel($title, 'supportus');
			?>
			<table class='adminlist'>
			<tr>
				<td>
					<p><?php echo JText::_('COM_J2XML_MSG_DONATION1'); ?></p>
					<div style="text-align: center;">
						<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
							<input type="hidden" name="cmd" value="_donations">
							<input type="hidden" name="business" value="info@eshiol.it">
							<input type="hidden" name="lc" value="en_US">
							<input type="hidden" name="item_name" value="eshiol.it">
							<input type="hidden" name="currency_code" value="EUR">
							<input type="hidden" name="bn" value="PP-DonationsBF:btn_donateCC_LG.gif:NonHosted">
							<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal secure payments.">
							<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
						</form>
					</div>
					<p><?php echo JText::_('COM_J2XML_MSG_DONATION2'); ?></p>
				</td>
			</tr>
			</table>
			<?php 
			echo $this->pane->endPanel();
			
			echo $this->pane->endPane();
			?>
		</td>
    </tr>
</table>
<form action="index.php" method="post" name="adminForm">
	<input type="hidden" name="option" value="com_j2xml" />
	<input type="hidden" name="c" value="website" />
	<input type="hidden" name="view" value="cpanel" />
	<input type="hidden" name="task" value="" />
	<?php echo JHTML::_('form.token'); ?>
</form>
