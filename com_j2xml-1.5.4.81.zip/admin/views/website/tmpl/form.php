<?php
/**
 * @version		1.5.3.47 views/website/tmpl/form.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @version		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');
?>

<?php 
	jimport('joomla.html.pane');

	$script =  "function submitbutton(pressbutton)\n"; 
	$script .= "{\n";
	$script .= "	var form = document.adminForm;\n";
	$script .= "	if (pressbutton == 'cancel') \n";
	$script .= "	{\n";
	$script .= "		submitform(pressbutton);\n";
	$script .= "		return;\n";
	$script .= "	}\n";
	$script .= "	// do field validation\n";
	$script .= "	if (form.title.value == \"\")\n";
	$script .= "	{\n";
	$script .= "		alert(\"".JText::_('Your item must have a title')."\");\n";
	$script .= "	}\n";
	$script .= "	else if (form.remote_url.value == \"\")\n";
	$script .= "	{\n";
	$script .= "		alert(\"".JText::_('You must insert the remote URL')."\");\n";
	$script .= "	}\n";
	$script .= "	else if (form.username.value == \"\")\n";
	$script .= "	{\n";
	$script .= "		alert(\"".JText::_('Your must insert the username')."\");\n";
	$script .= "	}\n";
	$script .= "	else if (form.password.value == \"\")\n";
	$script .= "	{\n";
	$script .= "		alert(\"".JText::_('You must insert the password')."\");\n";
	$script .= "	}\n";
	$script .= "	else\n"; 
	$script .= "	{\n";
//	$script .= $editor->save('text');
	$script .= "		submitform(pressbutton);\n";
	$script .= "	}\n";
	$script .= "}\n";
	$doc =& JFactory::getDocument();
	$doc->addScriptDeclaration($script);
?>


<form action="index.php" method="post" name="adminForm">
	<div class="col100">
		<fieldset class="adminform">
			<legend><?php echo JText::_( 'Details' ); ?></legend>

			<table class="admintable">
			<tbody>
				<tr>
					<td width="20%" class="key">
						<label for="title">
							<?php echo JText::_('Title'); ?>:
						</label>
					</td>
					<td width="80%">
						<input class="inputbox" type="text" name="title" id="title" size="50" value="<?php echo $this->data->title;?>" />
					</td>
				</tr>
				<tr>
					<td class="key">
						<?php echo JText::_('Enabled'); ?>:
					</td>
					<td>
						<?php echo $this->lists['published']; ?>
					</td>
				</tr>
				<tr>
					<td width="20%" class="key">
						<label for="remote_url">
							<?php echo JText::_('Remote URL'); ?>:
						</label>
					</td>
					<td width="80%">
						<input class="inputbox" type="text" name="remote_url" id="remote_url" size="50" value="<?php echo $this->data->remote_url;?>" />
					</td>
				</tr>
				<tr>
					<td class="key">
						<?php echo JText::_('Version'); ?>:
					</td>
					<td>
						<?php echo $this->lists['version']; ?>
					</td>
				</tr>
				<tr>
					<td class="key">
						<label for="username">
							<?php echo JText::_('Username'); ?>:
						</label>
					</td>
					<td>
						<input class="inputbox" type="text" name="username" id="username" size="50" value="<?php echo $this->data->username;?>" />
					</td>
				</tr>
				<tr>
					<td class="key">
						<label for="password">
							<?php echo JText::_('Password'); ?>:
						</label>
					</td>
					<td>
						<input class="inputbox" type="password" name="password" id="password" size="50" value="<?php echo $this->data->password;?>" />
					</td>
				</tr>
			</tbody>
			</table>
		</fieldset>
	</div>
	<div class="clr"></div>


	<input type="hidden" name="option" value="com_j2xml" />
	<input type="hidden" name="cid[]" value="<?php echo $this->data->id; ?>" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="c" value="website" />
	<?php echo JHTML::_('form.token'); ?>
</form>
