<?php
/**
 * @version		1.5.4.78 views/website/view.html.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @version		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010-2013 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.application.component.view');

/**
 * J2XML Component Website View
 */
class J2XMLViewWebsite extends JView
{
	function display($tmpl = null)
	{
		$app =& JFactory::getApplication('administrator');
		$data =& $this->get('Data');
		$this->assignRef('data', $data);

		// fail if checked out not by 'me'
		$user =& JFactory::getUser();
		$model =& $this->getModel();
		if ($model->isCheckedOut($user->get('id'))) {
			$msg = JText::sprintf('DESCBEINGEDITTED', JText::_('Website'), $data->title);
			$app->redirect('index.php?option=com_j2xml&task=website.show', $msg);
		} else if ($data->id > 0) {
			$model->checkout($user->get('id'));
		}
		// build the html lists
		$lists = array();
		$lists['published'] = JHTML::_('select.booleanlist', 'published', 'class="inputbox"', $data->published);

		$J2XMLVersions[] = JHTML::_('select.option', 0, '1.5');
		$J2XMLVersions[] = JHTML::_('select.option', 1, '1.6');
		$J2XMLVersions[] = JHTML::_('select.option', 2, '2.5+');
		$J2XMLVersions[] = JHTML::_('select.option', 3, 'Custom');
		$lists['version'] = JHTML::_('select.radiolist', $J2XMLVersions, 'version', 'class="inputbox"', 'value', 'text', $data->version);
		$this->assignRef('lists', $lists);
		
		parent::display($tmpl);
	}
}
?>
