<?php
/**
 * @version		1.5.4.72 views/content/view.raw.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3.17
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010-2013 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.application.component.view');

require_once (JPATH_COMPONENT.DS.'helpers'.DS.'exporter.php');
require_once (JPATH_COMPONENT.DS.'helpers'.DS.'version.php');

/**
 * J2XML Component Content View
 */
class J2XMLViewContent extends JView
{
	function display($tpl = null)
	{
		$app = JFactory::getApplication();
		$params = JComponentHelper::getParams('com_j2xml');
		
		$limit = JRequest::getVar('limit');

		if ($limit)
		{
			$db = JFactory::getDBO();
			$query = "SELECT id FROM #__content LIMIT {$limit}";
			$db->setQuery($query);
			$ids = $db->loadResultArray();
			$export_structure = 0;
		}
		else
		{
			$cid = JRequest::getVar('cid');		
			$ids = explode(",", $cid);
			$export_structure = 1;
			$export_users = $params->get('export_users', '1');			
		}
		$images = array();

		$xml = J2XMLExporter::contents($ids,
					$params->get('export_images', '1'),
					$export_structure,
					$export_users,
					$images
				);
		foreach ($images as $image)
			$xml .= $image;	
		
		if (!J2XMLExporter::export(
				$xml,		
				$params->get('debug', 0), 
				$params->get('export_gzip', '0')
			))
			$app->redirect('index.php?option=com_content');
	}
}
?>