<?php
/**
 * @version		1.5.4.74 controllers/cpanel.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport( 'joomla.application.component.controller' );

class J2XMLControllerCPanel extends JController
{
	/**
	 * @var		array	The controller messages.
	 * @since	
	 */
	private static $messages = array(
		0 => 'COM_J2XML_MSG_ARTICLE_IMPORTED',
		1 => 'COM_J2XML_MSG_ARTICLE_NOT_IMPORTED',
		2 => 'COM_J2XML_MSG_USER_IMPORTED',
		3 => 'COM_J2XML_MSG_USER_NOT_IMPORTED',
		4 => 'COM_J2XML_MSG_SECTION_IMPORTED',
		5 => 'COM_J2XML_MSG_SECTION_NOT_IMPORTED',
		6 => 'COM_J2XML_MSG_CATEGORY_IMPORTED',
		7 => 'COM_J2XML_MSG_CATEGORY_NOT_IMPORTED',
		8 => 'COM_J2XML_MSG_FOLDER_WAS_SUCCESSFULLY_CREATED',
		9 => 'COM_J2XML_MSG_ERROR_CREATING_FOLDER',
		10 => 'COM_J2XML_MSG_IMAGE_IMPORTED',
		11 => 'COM_J2XML_MSG_IMAGE_NOT_IMPORTED'							
		);	
	private static $codes = array(
		0 => 'message',
		1 => 'notice',
		2 => 'message',
		3 => 'notice',
		4 => 'message',
		5 => 'notice',
		6 => 'message',
		7 => 'notice',
		8 => 'notice',
		9 => 'error',
		10 => 'message',
		11 => 'notice'
		);	
	
	/**
	 * Custom Constructor
	 */
	function __construct( $default = array())
	{
		parent::__construct($default);
	}

	function display( )
	{
		JRequest::setVar('view', 'cpanel');
		//JRequest::setVar('layout', 'default');
		parent::display();
	}

	function import()
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit('Invalid Token');
		
		$app =& JFactory::getApplication('administrator');
		$msg='';
		$db =& JFactory::getDBO();
		$date = JFactory::getDate();
		$now = $date->toMYSQL();
		$params =& JComponentHelper::getParams('com_j2xml');

		libxml_use_internal_errors(true);
		
		//Retrieve file details from uploaded file, sent from upload form:
		$file = JRequest::getVar('file_upload', null, 'files', 'array');
		if ($file['name'])
		{
			$local = false;
			$filename = $file['tmp_name'];
		}
		else
		{
			$local = true;
			$filename = JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.JRequest::getVar('local_file', null);			
		}	
		// check if file is compress
		$path_info = pathinfo($filename);
		if ($path_info['extension'] == 'gz')
			$data = implode(gzfile($filename));
		else
			$data = file_get_contents($filename);
		if (function_exists('iconv'))
			$data = iconv("UTF-8","UTF-8//IGNORE",$data);
		$data = trim($data);
		$xml = simplexml_load_string($data);
				
		if (!$xml)
		{
			$errors = libxml_get_errors();
			foreach ($errors as $error) {
				$msg = $error->code.' - '.JText::_($error->message);
			    switch ($error->level) {
		    	default:
		        case LIBXML_ERR_WARNING:
		        	$app->enqueueMessage($msg,'message');
		            break;
		         case LIBXML_ERR_ERROR:
		        	$app->enqueueMessage($msg,'notice');
		            break;
		        case LIBXML_ERR_FATAL:
		        	$app->enqueueMessage($msg,'error');
		            break;
			    }
			}
			libxml_clear_errors();
		}

		if(!isset($xml['version']))
   			$app->enqueueMessage(JText::sprintf('COM_J2XML_MSG_FILE_FORMAT_UNKNOWN'),'error');
		else 
		{
			require_once (JPATH_COMPONENT.DS.'helpers'.DS.'importer.php');
			
			$xmlVersion = $xml['version'];
			$version = explode(".", $xmlVersion);
			$xmlVersionNumber = $version[0].$version[1].substr('0'.$version[2], strlen($version[2])-1); 
	
			if ($xmlVersionNumber == 1506)
				J2XMLImporter::import($xml,false,$xmlVersionNumber);
			else
				$app->enqueueMessage(JText::sprintf('COM_J2XML_MSG_FILE_FORMAT_NOT_SUPPORTED', $xmlVersion),'error');
		}	
		if ($local)
		{
			$local = $params->get('local', 1);
			if ($local == 1)
				JFile::move($filename, $filename.'.ok');
			elseif ($local == 2)
				JFile::delete($filename);
		}
		if ($params->get('debug', 0) == 0)
			$this->setRedirect('index.php?option=com_j2xml');	
	}
}