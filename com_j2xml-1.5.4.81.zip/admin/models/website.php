<?php
/**
 * @version		1.5.3.47 models/website.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.application.component.model');

/**
 * J2XML Component Website Model
 */
class J2XMLModelWebsite extends JModel 
{
	/**
	 * id
	 *
	 * @var int
	 */
	var $_id = null;

	/**
	 * data
	 *
	 * @var array
	 */
	var $_data = null;
	
	/**
	 * Constructor
	 *
	 * @access public
	 */
	function __construct() 
	{
		parent::__construct();
		$array = JRequest::getVar('cid', array(0), '', 'array');
		$edit = JRequest::getVar('edit', true);
		if($edit)
			$this->setId((int)$array[0]);
	}
	  
	/**
	 * Method to set the item identifier
	 *
	 * @access	public
	 * @param	int item identifier
	 */
	function setId($id)
	{
		// Set item id and wipe data
		$this->_id = $id;
		$this->_data = null;
	}
	  
	/**
	 * Method to get an item
	 */
	function &getData()
	{
		// Load the item data
		if (!$this->_loadData())
			$this->_initData();
		return $this->_data;
	}
	
	/**
	 * Method to store an item
	 *
	 * @access  public
	 * @return  boolean True on success
	 */
	function store($data)
	{
		$row =& $this->getTable();
		// Bind the form fields to the item table
		if (!$row->bind($data)) 
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		// Make sure the item record is valid
		if (!$row->check()) 
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		// Store the item record to the database
		if (!$row->store()) 
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		$this->_id = $row->id;
		$this->data->id = $row->id;
		return true;
	}
  
	/**
	 * Method to remove an item
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
	function delete()
	{
		$cids = JRequest::getVar('cid', array(0), 'post', 'array');
		$row =& $this->getTable('website');
		foreach($cids as $cid) 
		{
			if (!$row->delete($cid)) 
			{
				$this->setError($row->getErrorMsg());
				return false;
			}
		}
		return true;
	}

	/**
	 * Method to load item data
	 *
	 * @access	private
	 * @return	boolean	True on success
	 */
	function _loadData()
	{
		// Lets load the content if it doesn't already exist
		if (empty($this->_data))
		{
			$this->_db->setQuery($this->_buildQuery());
			$this->_data = $this->_db->loadObject();
			return (boolean) $this->_data;
		}
		return true;
	}

	/**
	 * Method to initialise item data
	 *
	 * @access	private
	 * @return	boolean	True on success
	 */
	function _initData()
	{
		// Lets load the content if it doesn't already exist
		if (empty($this->_data))
		{
			$data = new stdClass();
			$data->id = 0;
			$data->title = '';
			$data->remote_url = '';
			$data->version = 0;
			$data->username = '';
			$data->password = '';
			$data->checked_out = 0;
			$data->checked_out_time = 0;
			$data->published = 0;
			$this->_data = $data;
			return (boolean) $this->_data;
		}
		return true;
	}
	
	/**
	 * Method to get the data query
	 *
	 * @access	private
	 * @return	string query
	 */
	function _buildQuery()
	{
		$query = 'SELECT a.*'.
					' FROM #__j2xml_websites AS a' .
					' WHERE a.id = '.(int) $this->_id;
		return $query;
	}
	
	/**
	 * Tests if item is checked out
	 *
	 * @access	public
	 * @param	int	A user id
	 * @return	boolean	True if checked out
	 */
	function isCheckedOut($uid=0) 
	{
		if ($this->_loadData()) 
			if ($uid) 
				return ($this->_data->checked_out && $this->_data->checked_out != $uid);
			else 
				return $this->_data->checked_out;
	}

	/**
	 * Method to checkin/unlock the item
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
	function checkin()
	{
		if ($this->_id)
		{
			// Lets get to item and checkin it...
			$item = & $this->getTable();
			if(! $item->checkin($this->_id)) 
			{
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		}
		return false;
	}

	/**
	 * Method to checkout/lock the item
	 *
	 * @access	public
	 * @param	int	$uid	User ID of the user checking the item out
	 * @return	boolean	True on success
	 */
	function checkout($uid = null)
	{
		if ($this->_id)
		{
			// Make sure we have a user id to checkout the item with
			if (is_null($uid)) 
			{
				$user =& JFactory::getUser();
				$uid = $user->get('id');
			}
			// Lets get to item and checkout it...
			$item =& $this->getTable();
			if(!$item->checkout($uid, $this->_id)) 
			{
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * Method to (un)publish a item
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
	function publish($cid = array(), $publish = 1)
	{
		$user =& JFactory::getUser();
		if (count($cid))
		{
			JArrayHelper::toInteger($cid);
			$cids = implode( ',', $cid );
			$query = 'UPDATE #__j2xml_websites'
				. ' SET published = '.(int)$publish
				. ' WHERE id IN ('.$cids.')'
				. ' AND (checked_out = 0 OR (checked_out = '.(int) $user->get('id').'))'
			;
			$this->_db->setQuery( $query );
			if (!$this->_db->query()) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		}
		return true;
	}
}
?>