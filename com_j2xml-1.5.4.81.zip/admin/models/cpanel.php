<?php
/**
 * @version		1.5.3.56 models/cpanel.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.application.component.model');
jimport('joomla.plugin.plugin');
jimport('joomla.plugin.helper');
jimport('joomla.filesystem.file');
jimport('joomla.installer.installer');
jimport('joomla.installer.helper');

require_once(JPATH_CONFIGURATION.DS.'configuration.php');

class J2XMLModelCPanel extends JModel
{
	// Main constructer
	function __construct() {
		parent::__construct();
	}

	public function &getInfo() {
        $info = array();
		
        $info['extensions'] = $this->getExtensionInfo();
        
        return $info;
    }

	protected function &getExtensionInfo()  
	{
		static $extensionInfo;
		
        if (!isset($extensionInfo)) {
			$db =& JFactory::getDBO();
			$installer = new JInstaller();			
			$installer->SetPath('source', JPATH_COMPONENT_ADMINISTRATOR);
			$installer->setupInstall();
			require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_j2xml'.DS.'helpers'.DS.'xmlelement.php');
			$manifest = new JXMLElement($installer->getManifest()->document->toString());
			$extensions = $manifest->xpath('//install/extensions/plugin');
			foreach ($extensions as $ext)
			{
				$info = array();
				$info['type'] = 'plugin';

				$info['name'] = (string)$ext['name'];
				$info['group'] = (string)$ext['group'];
				$extName = 'plg_'.$info['group'].'_'.$info['name'];
					
				$query = 'SELECT id, published, name FROM `#__plugins`'
					. ' WHERE `folder`=\''.$info['group'].'\''
					. ' AND `element`=\''.$info['name'].'\'';
				$db->setQuery($query);
				$record = $db->loadAssoc();

 				if (!isset($record['id']))
 				{
 					$info['state'] = "not installed";
 					$info['version'] = '';
				}
				else
				{
					$info['id'] = $record['id'];
					$path = JPATH_ROOT.DS.'plugins'.DS.$info['group'].DS.$info['name'].'.xml';
					$pluginxml = simplexml_load_file($path);
					$plugin = $pluginxml->xpath('//install/version');
					$info['version'] = $plugin[0];					
					$info['name'] = $record['name'];
					$info['state'] = ($record['published'] == 0 ? 'disabled' : 'enabled');
				}
	
				$extensionInfo[] = $info;
			}
			
			$info = array();
			$info['type'] = 'configuration';
			$info['name'] = 'Web services';
			$info['group'] = 'system';
			$info['version'] = '';
			$jconfig = new JConfig();
			$info['state'] = ($jconfig->xmlrpc_server == 0 ? 'disabled' : 'enabled');
			$extensionInfo[] = $info;
        }
        return $extensionInfo;
	}
}