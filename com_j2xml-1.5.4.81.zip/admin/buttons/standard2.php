<?php
/**
 * @version		1.5.3.47 buttons/standard2.php * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.1
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * Toolbar Plugin System is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
// no direct access
defined('_JEXEC') or die('Restricted access.');
jimport('joomla.version');/** * Renders a standard2 button * */class JButtonStandard2 extends JButton{	/**	 * Button type	 *	 * @access	public	 * @var		string	 */	var $_name = 'Standard2';	public function fetchButton($type='Standard2', $name = '', $text = '', $task = '', $list = true, $hideMenu = false)	{		$i18n_text	= JText::_($text);		$class	= $this->fetchIconClass($name);		$doTask	= $this->_getCommand($text, $task, $list, $hideMenu);		$html  = "<a href=\"#\" onclick=\"$doTask\" class=\"toolbar\">\n";		$html .= "<span class=\"$class\" title=\"$i18n_text\">\n";		$html .= "</span>\n";		$html .= "$i18n_text\n";		$html .= "</a>\n";		return $html;	}	/**	 * Get the button CSS Id	 *	 * @access	public	 * @return	string	Button CSS Id	 * @since	1.5	 */	public function fetchId($type='Standard2', $name = '', $text = '', $task = '', $list = true, $hideMenu = false)	{		return $this->_getToolbarName().'-'.$name;	}	/**	 * Get the JavaScript command for the button	 *	 * @access	private	 * @param	string	$name	The task name as seen by the user	 * @param	string	$task	The task used by the application	 * @param	???		$list	 * @param	boolean	$hide	 * @return	string	JavaScript command string	 * @since	1.5	 */	private function _getCommand($name, $task, $list, $hide)	{		$todo		= JString::strtolower(JText::_( $name ));		$message	= JText::sprintf( 'Please make a selection from the list to', $todo );		$message	= addslashes($message);		$hidecode	= $hide ? 'hideMainMenu();' : '';				$tmp = explode('.', $task);		$i = count($tmp);		if ($i == 1)		{			$option = "				option1=document.adminForm.option.value;";		}		else if ($i == 2)		{
			$option = "				option1=document.adminForm.option.value;document.adminForm.option.value='com_$tmp[0]';";			$task = $tmp[1];		} 		else		{
			$option = "				option1=document.adminForm.option.value;
				document.adminForm.option.value='com_$tmp[0]';";
			$task = $tmp[1].'.'.$tmp[2];		} 		
		if ($list)			$code = "javascript:
				if(!document.adminForm.boxchecked){ 
					$hidecode 
					$option 
					submitbutton('$task');
					document.adminForm.task.value=''
				}
				else if(document.adminForm.boxchecked.value==0){
					alert('$message');
				}else{ 
					$hidecode 
					$option 
					submitbutton('$task');
					document.adminForm.option.value=option1;
					document.adminForm.task.value='';
				}
				";		else			$code = "javascript:
				$hidecode 
				$option 
				submitbutton('$task');
				document.adminForm.option.value=option1;
				document.adminForm.task.value='';
				";
		return $code;	}	/**	 * Get the name of the toolbar.	 *	 * @return	string	 * @since	1.5	 */	private function _getToolbarName()	{		return $this->_parent->_name;	}}