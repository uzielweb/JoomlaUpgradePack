<?php
/** 
 * @version		1.5.3.59 buttons/send.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.version');

/**
 * Renders a standard button
 *
 * @package 	Joomla.Framework
 * @subpackage		HTML
 * @since		1.5
 */
class JButtonSend extends JButton
{
	/**
	 * Button type
	 *
	 * @access	public
	 * @var		string
	 */
	var $_name = 'Send';

	function fetchButton( $type='Send', $name = '', $text = '', $task = '', $list = true, $hideMenu = false )
	{
		$i18n_text	= JText::_($text);
		$class	= $this->fetchIconClass($name);
		//$name = str_replace('-', '_', $name);
		$doTask	= $this->_getCommand($name, $text, $task);

		$html  = "";
		$html .= "<a $doTask class=\"toolbar\">\n";
		$html .= "<span class=\"$class\" title=\"$i18n_text\">\n";
		$html .= "</span>\n";
		$html .= "$i18n_text\n";
		$html .= "</a>\n";

		return $html;
	}

	/**
	 * Get the button CSS Id
	 *
	 * @access	public
	 * @return	string	Button CSS Id
	 * @since	1.5
	 */
	function fetchId( $type='Send', $name = '', $text = '', $task = '', $list = true, $hideMenu = false )
	{
		return $this->_getToolbarName().'-'.$name;
	}

	/**
	 * Get the JavaScript command for the button
	 *
	 * @access	private
	 * @param	string	$name	The task name as seen by the user
	 * @param	string	$task	The task used by the application
	 * @param	???		$list
	 * @param	boolean	$hide
	 * @return	string	JavaScript command string
	 * @since	1.5
	 */
	function _getCommand($name, $text, $task)
	{
		$todo		= JString::strtolower(JText::_( $text ));
		$message	= JText::sprintf( 'Please make a selection from the list to', $todo );
		$message	= addslashes($message);
		$doc =& JFactory::getDocument();
				

		$tmp = explode('.', $task);
		$link = "index.php?option=com_$tmp[0]&amp;task=website.element&amp;tmpl=component&amp;object=$name";
		$task = $tmp[1].'.'.$tmp[2];
		
		// Browser
		jimport('joomla.environment.browser');
		$browser = & JBrowser::getInstance();
		
		// Use "popup" mode for IE
		if ($browser->getBrowser() == 'msie')
		{
			$modal	= false;
			$link .= '&amp;mode=popup';
			
			// Insert script
			JHTML::_('behavior.mootools');
			$doc->addScriptDeclaration("
				function jSelectWebsite(id, title, object) {
					var input = document.createElement('input');
					input.setAttribute('type', 'hidden');
					input.setAttribute('name', object+'_id');
					input.setAttribute('value', id);
					document.adminForm.appendChild(input);
					document.adminForm.option.value='com_$tmp[0]';
					submitbutton('$task');
				}");
			$doc->addScriptDeclaration(
				'function popWebsites(a)
				{
					// Window position
					var s	= window.getSize().size;
					var t	= ((s.y - 480) / 2).round();
					var l	= ((s.x - 800) / 2).round();
					
					// Open Websites
					window.open(a.href, "websites", "dependent=1,scrollbars=1,width=800,height=480,top="+ t +",left="+ l);
					return false;
				}
				'
			);
		}
		// Regular squeezebox
		else 
		{
			$modal = true;
			JHTML::_('behavior.modal', 'a.modal');
			$doc->addScriptDeclaration("
				function jSelectWebsite(id, title, object) {
					var input = document.createElement('input');
					input.setAttribute('type', 'hidden');					
					input.setAttribute('name', object+'_id');
					input.setAttribute('value', id);
					document.adminForm.appendChild(input);					
					$('sbox-window').close();		
					document.adminForm.option.value='com_$tmp[0]';
					submitbutton('$task');
				}");
		}
		$link .= '&amp;'.JUtility::getToken().'=1';

		$cmd = "
			href=\"$link\"
			onclick=\"javascript:
				if(document.adminForm.boxchecked.value==0)
				{
					alert('$message');
					return false;
				}
				else
				{
					".($modal?'':'return popWebsites(this);')."
					return false;
				}
				\"
			".
			($modal?'class="modal" rel="{handler: \'iframe\', size: {x: 800, y: 480}}"':'')
			;
		return $cmd;
	}

	/**
	 * Get the name of the toolbar.
	 *
	 * @return	string
	 * @since	1.5
	 */
	private function _getToolbarName()
	{
		$version = new JVersion();
		if ($version->RELEASE == '1.5')		
			return $this->_parent->_name;
		else
			return $this->_parent->getName();
	}
}