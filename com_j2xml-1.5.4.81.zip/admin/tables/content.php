<?php
/**
 * @version		1.5.4.81 administrator/components/com_j2xml/tables/content.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.1
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010-2015 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
  * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
*/
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

class eshTableContent extends eshTable
{
	/** @var int Primary key */
	var $id					= null;
	/** @var string */
	var $title				= null;
	/** @var string */
	var $alias				= null;
	/** @var string */
	var $title_alias		= null;
	/** @var string */
	var $introtext			= null;
	/** @var string */
	var $fulltext			= null;
	/** @var int */
	var $state				= null;
	/** @var int The id of the category section*/
	var $sectionid			= null;
	/** @var int DEPRECATED */
	var $mask				= null;
	/** @var int */
	var $catid				= null;
	/** @var datetime */
	var $created			= null;
	/** @var int User id*/
	var $created_by			= null;
	/** @var string An alias for the author*/
	var $created_by_alias	= null;
	/** @var datetime */
	var $modified			= null;
	/** @var int User id*/
	var $modified_by		= null;
	/** @var boolean */
	var $checked_out		= 0;
	/** @var time */
	var $checked_out_time	= 0;
	/** @var datetime */
	var $publish_up			= null;
	/** @var datetime */
	var $publish_down		= null;
	/** @var string */
	var $images				= null;
	/** @var string */
	var $urls				= null;
	/** @var string */
	var $attribs			= null;
	/** @var int */
	var $version			= null;
	/** @var int */
	var $parentid			= null;
	/** @var int */
	var $ordering			= null;
	/** @var string */
	var $metakey			= null;
	/** @var string */
	var $metadesc			= null;
	/** @var string */
	var $metadata			= null;
	/** @var int */
	var $access				= null;
	/** @var int */
	var $hits				= null;
	/** @var int */
	var $frontpage			= null;
	/** @var int */
	var $rating_sum		= null;
	/** @var int */
	var $rating_count		= null;
	
	/**
	* @param database A database connector object
	*/
	function __construct(&$db) {
		parent::__construct('#__content', 'id', $db);
	}

	/**
	 * Loads a row from the database and binds the fields to the object properties
	 *
	 * @access	public
	 * @param	mixed	Optional primary key.  If not specifed, the value of current key is used
	 * @return	boolean	True if successful
	 */
	function load($oid=null)
	{
		parent::load($oid);
		
		$db =& $this->getDBO();

		$query = 'SELECT ordering'
			. ' FROM #__content_frontpage'
			. ' WHERE content_id = '. (int)$oid
			;
		$db->setQuery($query);
		$this->frontpage = (int)$db->loadResult();
		
		$query = 'SELECT rating_sum, rating_count'
			. ' FROM #__content_rating'
			. ' WHERE content_id = '. $oid;
		$db->setQuery($query);
		if ($result = $db->loadAssoc()) 
		{
			$this->rating_sum = $result['rating_sum'];
			$this->rating_count = $result['rating_count'];
		}
	}

	/**
	 * Overloaded check function
	 *
	 * @access public
	 * @return boolean
	 * @see JTable::check
	 * @since 1.5
	 */
	function check()
	{
		/*
		TODO: This filter is too rigorous,need to implement more configurable solution
		// specific filters
		$filter = & JFilterInput::getInstance( null, null, 1, 1 );
		$this->introtext = trim( $filter->clean( $this->introtext ) );
		$this->fulltext =  trim( $filter->clean( $this->fulltext ) );
		*/


		if(empty($this->title)) {
			$this->setError(JText::_('Article must have a title'));
			return false;
		}

		if(empty($this->alias)) {
			$this->alias = $this->title;
		}
		$this->alias = JFilterOutput::stringURLSafe($this->alias);

		if(trim(str_replace('-','',$this->alias)) == '') {
			$datenow =& JFactory::getDate();
			$this->alias = $datenow->toFormat("%Y-%m-%d-%H-%M-%S");
		}

		if (trim( str_replace( '&nbsp;', '', $this->fulltext ) ) == '') {
			$this->fulltext = '';
		}

		if(empty($this->introtext) && empty($this->fulltext)) {
			$this->setError(JText::_('Article must have some text'));
			return false;
		}

		// clean up keywords -- eliminate extra spaces between phrases
		// and cr (\r) and lf (\n) characters from string
		if(!empty($this->metakey)) { // only process if not empty
			$bad_characters = array("\n", "\r", "\"", "<", ">"); // array of characters to remove
			$after_clean = JString::str_ireplace($bad_characters, "", $this->metakey); // remove bad characters
			$keys = explode(',', $after_clean); // create array using commas as delimiter
			$clean_keys = array(); 
			foreach($keys as $key) {
				if(trim($key)) {  // ignore blank keywords
					$clean_keys[] = trim($key);
				}
			}
			$this->metakey = implode(", ", $clean_keys); // put array back together delimited by ", "
		}
		
		// clean up description -- eliminate quotes and <> brackets
		if(!empty($this->metadesc)) { // only process if not empty
			$bad_characters = array("\"", "<", ">");
			$this->metadesc = JString::str_ireplace($bad_characters, "", $this->metadesc);
		}

		return true;
	}

	/**
	 * Inserts a new row if id is zero or updates an existing row in the database table
	 *
	 * Can be overloaded/supplemented by the child class
	 *
	 * @access public
	 * @param boolean If false, null object variables are not updated
	 * @return null|string null if successful otherwise returns and error message
	 */
	function store($updateNulls=false)
	{
		// backup extrafields
		$frontpage = $this->frontpage;
		$rating_sum = $this->rating_sum;
		$rating_count = $this->rating_count;
		// delete extrafields
		unset($this->frontpage);
		unset($this->rating_sum);
		unset($this->rating_count);
		// save fields
		$ret = parent::store($updateNulls);
		// restore extrafields
		$this->frontpage = $frontpage;
		$this->rating_sum = $rating_sum;
		$this->rating_count = $rating_count;
		
		$db =& $this->getDBO();
		if ($updateNulls || ($this->frontpage != null))
		{
			$query = 'SELECT content_id FROM #__content_frontpage WHERE content_id = ' .$this->id;
			$db->setQuery($query);
			$id = $db->loadResult();
			if ($this->frontpage == 0)
			{
				$query = 'DELETE FROM #__content_frontpage'
					. ' WHERE content_id = '.(int)$this->id	
					;
				$db->setQuery($query);
				$db->query();	
			} 
			else if ($id > 0)
			{
				$query = 'UPDATE #__content_frontpage '
					. ' SET ordering = '.((int)$this->frontpage)
					. ' WHERE content_id = '.(int)$this->id	
					;
				$db->setQuery($query);
				$db->query();
			}
			else 
			{
 				/*
				// inserisci in coda
				$query = 'SELECT MAX(ordering) FROM #__content_frontpage';	
				$db->setQuery($query);
				$frontpage = (int)$db->loadResult() + 1;
				*/
				$query = 'INSERT INTO #__content_frontpage (content_id, ordering)'
					. ' VALUES ('.(int)$this->id.','.$frontpage.')'	
					;
				$db->setQuery($query);
				$db->query();
			}
		}

		if ($updateNulls || ($this->rating_count != null))
		{
			$query = 'SELECT content_id FROM #__content_rating WHERE content_id = ' .$this->id;
			$db->setQuery($query);
			$id = $db->loadResult();
			if ($this->rating_count == 0)
			{
				$query = 'DELETE FROM #__content_rating '
					.' WHERE content_id = '.(int)$this->id;							
				$db->setQuery($query);
				$db->query();	
			}
			else if ($id > 0)
			{
				$query = 'UPDATE #__content_rating SET '
					. 'rating_sum = '.(int)$this->rating_sum.','
					. 'rating_count = '.(int)$this->rating_count
					.' WHERE content_id = '.(int)$this->id;							
				$db->setQuery($query);
				$db->query();	
			}
			else
			{
				$query = 'INSERT INTO #__content_rating (content_id, rating_sum, rating_count, lastip)'
					. ' VALUES ('.(int)$this->id.','
					. (int)$this->rating_sum.','
					. (int)$this->rating_count.',\''.$_SERVER['REMOTE_ADDR'].'\')';
				$db->setQuery($query);
				$db->query();	
			}
		}	
	
		return $ret;
	}
		
	/**
	 * Export item list to xml
	 *
	 * @access public
	 * @param boolean Map foreign keys to text values
	 */
	function toXML( $mapKeysToText=false )
	{
		$db =& JFactory::getDBO();
		
		$sectionid = $this->sectionid;
		$catid = $this->catid;
		
		if ($mapKeysToText) 
		{
			$query = 'SELECT IF(alias!="", alias, name) alias, title, id'
				. ' FROM #__sections'
				. ' WHERE id = '. (int)$this->sectionid
				;
			$db->setQuery($query);
			$section = $db->loadObject();
			$this->sectionid = JFilterOutput::stringURLSafe(trim($section->alias));
			if(trim(str_replace('-','',$this->sectionid)) == '')
				$this->sectionid = JFilterOutput::stringURLSafe(trim($section->title));
			if(trim(str_replace('-','',$this->sectionid)) == '')
				$this->sectionid = 'section-'.$section->id;
			$this->sectionid = str_replace(' ', '-', trim(str_replace('-', ' ', $this->sectionid)));
				
			$query = 'SELECT IF(alias!="", alias, name) alias, title, id'
				. ' FROM #__categories'
				. ' WHERE id = '. (int)$this->catid
				;
			$db->setQuery($query);
			$category = $db->loadObject();
			$this->catid = JFilterOutput::stringURLSafe(trim($category->alias));
			if(trim(str_replace('-','',$this->catid)) == '')
				$this->catid = JFilterOutput::stringURLSafe(trim($category->title));
			if(trim(str_replace('-','',$this->catid)) == '')
				$this->catid = 'category-'.$category->id;
			$this->catid = str_replace(' ', '-', trim(str_replace('-', ' ', $this->catid)));
				
			$query = 'SELECT username'
				. ' FROM #__users'
				. ' WHERE id = ' . (int)$this->created_by
				;
			$db->setQuery($query);
			$user = $db->loadResult();
			if ($this->modified_by == $this->created_by)
				$this->modified_by = $user;
			else if ((int)$this->modified_by > 0)
			{
				$query = 'SELECT username'
					. ' FROM #__users'
					. ' WHERE id = ' . (int)$this->modified_by
					;
				$db->setQuery($query);
				$this->modified_by = $db->loadResult();
			}
			$this->created_by = $user;
		}
		$this->title = htmlspecialchars($this->title);
		$this->introtext = htmlspecialchars($this->introtext);
		$this->fulltext = htmlspecialchars($this->fulltext);
		
		$alias = $this->alias;
		$this->alias = JFilterOutput::stringURLSafe($alias);
		if(trim(str_replace('-','',$this->alias)) == '')
			$this->alias = JFilterOutput::stringURLSafe($this->title);
		if(trim(str_replace('-','',$this->alias)) == '')
			$this->alias = 'category-'.$this->id;
		$this->alias = str_replace(' ', '-', trim(str_replace('-', ' ', $this->alias)));
		
		$query = 'SELECT CONCAT(\'index.php?option=com_content&view=article&id=\',a.id,\':\',a.alias,
				IF(a.catid, CONCAT(\'&catid=\',a.catid,\':\',c.alias),\'\'),
				IF(m.id, CONCAT(\'&Itemid=\',m.id), \'\'))
				FROM #__content a
				LEFT JOIN #__categories c ON a.catid = c.id
				LEFT JOIN #__menu m ON m.link = CONCAT(\'index.php?option=com_content&view=article&id=\',a.id)
				WHERE a.id = '.(int)$this->id;
		$db->setQuery($query);
		$this->canonical = $db->loadResult();
		
		$xml = '<content'.($mapKeysToText ? ' mapkeystotext="true"' : '').'>';
		$xml .= parent::toXML($mapKeysToText);
		$xml .= '</content>';
		
		$this->sectionid = $sectionid;
		$this->catid = $catid;
		$this->alias = $alias;
		unset($this->canonical);
		
		return $xml;
	}
}
