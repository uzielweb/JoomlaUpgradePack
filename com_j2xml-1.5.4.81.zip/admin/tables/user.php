<?php
/**
 * @version		1.5.3.47 tables/user.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3beta4.39
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* User Table class
* @since 		1.5.3beta4.39
*/
class eshTableUser extends eshTable
{
	/**
	 * Unique id
	 *
	 * @var int
	 */
	var $id				= null;

	/**
	 * The users real name (or nickname)
	 *
	 * @var string
	 */
	var $name			= null;

	/**
	 * The login name
	 *
	 * @var string
	 */
	var $username		= null;

	/**
	 * The email
	 *
	 * @var string
	 */
	var $email			= null;

	/**
	 * MD5 encrypted password
	 *
	 * @var string
	 */
	var $password		= null;

	/**
	 * Description
	 *
	 * @var string
	 */
	var $usertype		= null;

	/**
	 * Description
	 *
	 * @var int
	 */
	var $block			= null;

	/**
	 * Description
	 *
	 * @var int
	 */
	var $sendEmail		= null;

	/**
	 * The group id number
	 *
	 * @var int
	 */
	var $gid			= null;

	/**
	 * Description
	 *
	 * @var datetime
	 */
	var $registerDate	= null;

	/**
	 * Description
	 *
	 * @var datetime
	 */
	var $lastvisitDate	= null;

	/**
	 * Description
	 *
	 * @var string activation hash
	 */
	var $activation		= null;

	/**
	 * Description
	 *
	 * @var string
	 */
	var $params			= null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.5.3beta4.39
	 */
	function __construct(& $db) {
		parent::__construct('#__users', 'id', $db);
	}

	/**
	* Overloaded toXML function
	*
	* @acces public
	* @param boolean Map foreign keys to text values
	* @see JTable:toXML
	* @since 1.5.3beta3.38
	*/
	function toXML( $mapKeysToText=false )
	{
		$xml = '<user'.($mapKeysToText ? ' mapkeystotext="true"' : '').'>';
		$xml .= parent::toXML($mapKeysToText);
		$xml .= '</user>';
		return $xml;
	}
}
