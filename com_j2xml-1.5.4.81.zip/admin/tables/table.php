<?php
/**
 * @version		1.5.4.74 tables/table.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3beta4.39
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
*/
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

class eshTable extends JTable
{
	/**
	 * Object constructor to set table and key field
	 *
	 * Can be overloaded/supplemented by the child class
	 *
	 * @access protected
	 * @param string $table name of the table in the db schema relating to child class
	 * @param string $key name of the primary key field in the table
	 * @param object $db JDatabase object
	 */
	function __construct($table, $key, &$db)
	{
		parent::__construct($table, $key, $db);
	}
		
	/**
	 * Removes invalid XML
	 *
	 * @access public
	 * @param string $value
	 * @return string
	 */
	private function stripInvalidXml($value)
	{
		if (!is_string($value)) return $value;
		
		$ret = "";
		$current;
	
		$length = strlen($value);
		for ($i=0; $i < $length; $i++)
		{
			$current = ord($value{$i});
			if (($current == 0x9) ||
				($current == 0xA) ||
				($current == 0xD) ||
				(($current >= 0x20) && ($current <= 0xD7FF)) ||
				(($current >= 0xE000) && ($current <= 0xFFFD)) ||
				(($current >= 0x10000) && ($current <= 0x10FFFF)))
				{
					$ret .= chr($current);
				}
			else
			{
				$ret .= " ";
			}
		}
		return $ret;
	}
	
	/**
	 * Export item list to xml
	 *
	 * @access public
	 * @param boolean Map foreign keys to text values
	 */
	function toXML( $mapKeysToText=false )
	{
		$xml = '';
		foreach (get_object_vars($this) as $k => $v)
		{
			if (is_array($v) or is_object($v) or $v === NULL)
				continue;
			if ($k[0] == '_') // internal field
				continue;
			$xml .= '<' . $k . '><![CDATA[' . 
				$this->stripInvalidXml($v)
			 	. ']]></' . $k . '>'
			 	. "\n";
		}
		return $xml;
	}
}
