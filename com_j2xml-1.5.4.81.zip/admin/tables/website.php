<?php
/**
 * @version		1.5.4.72 tables/website.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @version		1.5.3
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

/**
 * Website Table class
 */
class TableWebsite extends JTable
{
	/**
	 * Primary key
	 *
	 * @var int
	 */
	var $id = null;
  
	/**
	 * @var string
	 */
	var $title = null;
	
	/**
	 * @var boolean
	 */ 
	var $checked_out = 0;
	
	/**
	 * @var time  
	 */ 
	var $checked_out_time = 0; 
	
	/**
	 * @var int
	 */
	var $published = 0;
	
	/**
	 * @var string
	 */
	var $remote_url = null;
	
	/**
	 * @var string
	 */
	var $username = null;
	
	/**
	 * @var string
	 */
	var $password = null;
	
	/**
	 * @var int
	 * 0 = 1.5, 1 = 1.6 (importer), 2 = 2.5
	 */
	var $version = null;
	
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @access public
	 */
	function TableWebsite(&$db)
	{
		parent::__construct('#__j2xml_websites', 'id', $db);
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 */
	function check()
	{
		if (!$this->title) 
		{
			$this->setError(JText::_('Your item must have a title'));
			return false;
		}
		return true;
	}
}
?>
