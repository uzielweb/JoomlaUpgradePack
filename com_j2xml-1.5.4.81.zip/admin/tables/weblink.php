<?php
/**
 * @version		1.5.3.59 tables/weblink.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.3beta3.38
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Weblink Table class
*/
class eshTableWeblink extends eshTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var int
	 */
	var $catid = null;

	/**
	 * @var int
	 */
	var $sid = null;

	/**
	 * @var string
	 */
	var $title = null;

	/**
	 * @var string
	 */
	var $alias = null;

	/**
	 * @var string
	 */
	var $url = null;

	/**
	 * @var string
	 */
	var $description = null;

	/**
	 * @var datetime
	 */
	var $date = null;

	/**
	 * @var int
	 */
	var $hits = null;

	/**
	 * @var int
	 */
	var $published = null;

	/**
	 * @var boolean
	 */
	var $checked_out = 0;

	/**
	 * @var time
	 */
	var $checked_out_time = 0;

	/**
	 * @var int
	 */
	var $ordering = null;

	/**
	 * @var int
	 */
	var $archived = null;

	/**
	 * @var int
	 */
	var $approved = null;

	/**
	 * @var string
	 */
	var $params = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.5.3beta3.38
	 */
	function __construct(& $db) {
		parent::__construct('#__weblinks', 'id', $db);
	}

	/**
	* Overloaded toXML function
	*
	* @acces public
	* @param boolean Map foreign keys to text values
	* @see JTable:toXML
	* @since 1.5.3beta3.38
	*/
	function toXML( $mapKeysToText=false )
	{
		$db =& JFactory::getDBO();
		
		if ($mapKeysToText) {
			$query = 'SELECT alias'
				. ' FROM #__categories'
				. ' WHERE id = '. (int)$this->catid
				;
			$db->setQuery($query);
			$this->catid = $db->loadResult();
		}
		$this->title = htmlspecialchars($this->title);
		$this->description = htmlspecialchars($this->description);
		
		$xml = '<weblink'.($mapKeysToText ? ' mapkeystotext="true"' : '').'>';
		$xml .= parent::toXML($mapKeysToText);
		$xml .= '</weblink>';
		return $xml;
	}
}
