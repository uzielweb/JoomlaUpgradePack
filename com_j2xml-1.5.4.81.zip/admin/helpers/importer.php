<?php
/**
 * @version		1.5.3.59 helpers/importer.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.1
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010-2011 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XMLImporter is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

class J2XMLImporter
{
	private static $messages = array(
		'articleok' => 'COM_J2XML_MSG_ARTICLE_IMPORTED',
		'articlenotok' => 'COM_J2XML_MSG_ARTICLE_NOT_IMPORTED',	
		'userok' => 'COM_J2XML_MSG_USER_IMPORTED',
		'usernotok' => 'COM_J2XML_MSG_USER_NOT_IMPORTED',
		'sectionok' => 'COM_J2XML_MSG_SECTION_IMPORTED',
		'sectionnotok' => 'COM_J2XML_MSG_SECTION_NOT_IMPORTED',
		'categoryok' => 'COM_J2XML_MSG_CATEGORY_IMPORTED',
		'categorynotok' => 'COM_J2XML_MSG_CATEGORY_NOT_IMPORTED',
		'folderok' => 'COM_J2XML_MSG_FOLDER_WAS_SUCCESSFULLY_CREATED',
		'foldernotok' => 'COM_J2XML_MSG_ERROR_CREATING_FOLDER',
		'imageok' => 'COM_J2XML_MSG_IMAGE_IMPORTED',
		'imagenotok' => 'COM_J2XML_MSG_IMAGE_NOT_IMPORTED',						
		'weblinkok' => 'COM_J2XML_MSG_WEBLINK_IMPORTED',
		'weblinknotok' => 'COM_J2XML_MSG_WEBLINK_NOT_IMPORTED',	
		'weblinkcatnotok' => 'COM_J2XML_MSG_WEBLINKCAT_NOT_PRESENT',	
	);				
	private static $codes = array(
		'articleok' => 0,
		'articlenotok' => 1,
		'userok' => 2,
		'usernotok' => 3,
		'sectionok' => 4,
		'sectionnotok' => 5,
		'categoryok' => 6,
		'categorynotok' => 7,
		'folderok' => 8,
		'foldernotok' => 9,
		'imageok' => 10,
		'imagenotok' => 11,
		'weblinkok' => 12,
		'weblinknotok' => 13,
		'weblinkcatnotok' => 14,
	);	

	private static $gids = array(
		'Registered' => 18,
		'Author' => 19,
		'Editor' => 20,
		'Publisher' => 21,
		'Manager' => 23,
		'Administrator' => 24,
		'Super Administrator' => 25,
	);
	
	static function import($xml, $xmlrpc = false, $filever)
	{
		$msg = array();
		$db =& JFactory::getDBO();
		$nullDate = $db->getNullDate();
		$user = JFactory::getUser();
		$user_id = $user->get('id');
		$now =& JFactory::getDate()->toFormat("%Y-%m-%d-%H-%M-%S");
		$params =& JComponentHelper::getParams('com_j2xml');
		
		$sections_id = array();
		$sections_id['com_weblinks'] = 'com_weblinks';
		
		$sections_title = array();
		$sections_title['com_weblinks'] = 'com_weblinks';
		
		$users_id = array();
		$users_id['admin'] = 62;
		$users_id[0] = 0;
		
		$import_content = $params->get('import_content', '2');
		$import_users = $params->get('import_users', '1');
		$import_categories = $params->get('import_categories', '1');
		$import_images = $params->get('import_images', '1');
		$import_weblinks = $params->get('import_weblinks', '1');
		
		$keep_access = $params->get('keep_access', '0');
		$keep_state = $params->get('keep_state', '2');
		$keep_author = $params->get('keep_author', '1');
		$keep_category = $params->get('keep_category', '1');
		$keep_attribs = $params->get('keep_attribs', '1');
		$keep_metadata = $params->get('keep_metadata', '1');
		$keep_frontpage = $params->get('keep_frontpage', '1');
		$keep_rating = $params->get('keep_rating', '1');
		
		if ($import_users)
		{
			foreach($xml->xpath("user") as $record)
			{
				$data = array();
				foreach($record->children() as $key => $value)
					$data[trim($key)] = trim($value);
				$alias = $data['username'];
				$query = 'SELECT id, name'
					. ' FROM #__users'
					. ' WHERE username = '. $db->Quote($alias);
					;
				$db->setQuery($query);
				$user = $db->loadObject();
				if (!$user || ($import_users == 2))
				{
					$table =& JTable::getInstance('user', 'eshTable');
					if ($user)
					{
						$data['id'] = $user->id;
						$table->load($data['id']);
					}
					else
					{
						$data['id'] = null;
					}
					
					// Add the groups to the user data.
					$data['gid'] = self::$gids[$data['usertype']];					
					
					if (!$keep_attribs)
						$data['attribs'] = null;
						 
					if ($table->save($data))
					{
						$users_id[$alias] = $table->id;
						$users_title[$alias] = $table->name;
						self::trace(true, $xmlrpc, $table->name, 'user', $msg);

						$acl =& JFactory::getACL();						
						$section_value = 'users';
						if ($user)
						{
							// syncronise ACL
							// single group handled at the moment
							// trivial to expand to multiple groups
							$object_id = $acl->get_object_id($section_value, $table->id, 'ARO');
				
							$groups = $acl->get_object_groups( $object_id, 'ARO');
							$acl->del_group_object($groups[0], $section_value, $table->id, 'ARO');
							$acl->add_group_object($table->gid, $section_value, $table->id, 'ARO');
				
							$acl->edit_object($object_id, $section_value, $db->getEscaped($table->name), $table->id, 0, 0, 'ARO');							
						}
						else 
						{
							$i = $acl->add_object($section_value, $table->name, $table->id, null, null, 'ARO');
							$acl->add_group_object($table->gid, $section_value, $table->id, 'ARO');		
						}
					}
					else
						self::trace(false, $xmlrpc, $data['name'], 'user', $msg);
				}
				elseif ($user)
				{
					$users_id[$alias] = $user->id;
					$users_title[$alias] = $user->name;
				}
			}
		}

		if ($import_categories)
		{
			foreach($xml->xpath("section") as $record)
			{
				$data = array();
				foreach($record->children() as $key => $value)
					$data[trim($key)] = trim($value);
				$alias = $data['alias'];
				if ($filever >= 1506)
					$data['title'] = htmlspecialchars_decode($data['title']);				
				$data['description'] = htmlspecialchars_decode($data['description']);
				// add field not used
				$data['scope'] = 'content';
				
				$query = 'SELECT id, title'
					. ' FROM #__sections'
					. ' WHERE alias = '. $db->Quote($alias)
					;
				$db->setQuery($query);
				$section = $db->loadObject();
				if (!$section || ($import_categories == 2))
				{
					$data['checked_out'] = 0;
					$data['checked_out_time'] = $nullDate;
					
					$table =& JTable::getInstance('section', 'eshTable');
					if (!$section) // new section
					{
						$data['id'] = null;
						if ($keep_access > 0)
							$data['access'] = $keep_access;
						if ($keep_state < 2)
							// Force the state
							$data['published'] = $keep_state;
						//else keep the original state
						
						if ($keep_attribs)
							$data['params'] = '';
					}
					else // section already exists
					{
						$data['id'] = $section->id;
						$table->load($data['id']);
						
						if ($keep_access > 0)
							// don't modify the access level
							$data['access'] = null;
						
						if ($keep_state != 0)  
							// don't modify the state
							$data['published'] = null;
						//else keep the original state		

						if (!$keep_attribs)
							$data['params'] = null;						
					}
										
					if ($table->save($data))
					{
						$sections_id[$alias] = $table->id;
						$sections_title[$alias] = $table->title;
						self::trace(true, $xmlrpc, $table->title, 'section', $msg);
					}
					else
						self::trace(false, $xmlrpc, $data['title'], 'section', $msg);
				}
				elseif ($section)
				{
					$sections_id[$alias] = $section->id;
					$sections_title[$alias] = $section->title;
				}
			}
		}

		if ($import_categories)
		{
			foreach($xml->xpath("category".($import_weblinks ? '' : "[sectionid!='com_weblinks']")) as $record)
			{
				$data = array();
				foreach($record->children() as $key => $value)
					$data[trim($key)] = trim($value);
				$alias = $data['alias'];
				$data['section'] = $data['sectionid'];
				unset($data['sectionid']);
				$section_alias = $data['section'];
				if ($filever >= 1506)
					$data['title'] = htmlspecialchars_decode($data['title']);				
				$data['description'] = htmlspecialchars_decode($data['description']);
				if (!isset($sections_id[$section_alias]))
				{
					$query = 'SELECT id, title'
						. ' FROM #__sections'
						. ' WHERE alias = '. $db->Quote($section_alias)
						;
					$db->setQuery($query);
					list($sections_id[$section_alias], $sections_title[$section_alias]) = $db->loadResultArray(); 
				}
				$section_id = $sections_id[$section_alias];
				if (!$section_id)
				{
					self::trace(false, $xmlrpc, $section_alias.'/'.$data['title'], 'category', $msg);
					break;
				}
				$section_title = $sections_title[$section_alias];
				$data['section'] = $section_id;
				$query = 'SELECT id, title'
					. ' FROM #__categories'
					. ' WHERE alias = '. $db->Quote($alias)
					. ' AND section = '. $db->Quote($section_id)
					;
				$db->setQuery($query);
				$category = $db->loadObject();
				if (!$category || ($import_categories == 2))
				{
					$data['checked_out'] = 0;
					$data['checked_out_time'] = $nullDate;
					$table =& JTable::getInstance('category', 'eshTable');

					if (!$category) // new category
					{
						$data['id'] = null;
						if ($keep_access > 0)
							$data['access'] = $keep_access;
						if ($keep_state < 2)
							// Force the state
							$data['published'] = $keep_state;
						//else keep the original state
						
						if (!$keep_attribs)
							$data['params'] = '';							
					}
					else // category already exists
					{
						$data['id'] = $category->id;
						$table->load($data['id']);
						
						if ($keep_access > 0)
							// don't modify the access level
							$data['access'] = null;
						
						if ($keep_state != 0)  
							// don't modify the state
							$data['published'] = null;
						//else keep the original state		

						if (!$keep_attribs)
							$data['params'] = null;							
					}
					if ($table->save($data))
					{
						$categories_id[$section_alias.'/'.$alias] = $table->id;
						$categories_title[$section_alias.'/'.$alias] = $table->title;
						self::trace(true, $xmlrpc, $section_title.'/'.$table->title, 'category', $msg);
					}
					else
					{
						self::trace(false, $xmlrpc, $section_title.'/'.$data['title'], 'category', $msg);
					}
				}
				elseif ($category)
				{
					$categories_id[$section_alias.'/'.$alias] = $category->id;
					$categories_title[$section_alias.'/'.$alias] = $category->title;
				}
			}
		}

		if ($keep_frontpage)
		{
			$query = 'SELECT max(ordering)'
				. ' FROM #__content_frontpage'
				;
			$db->setQuery($query);
			$frontpage = (int)$db->loadResult();				
		}
		
		if ($import_content)
		{
			foreach($xml->xpath("content") as $record)
			{
				$attributes = $record->attributes();
				$data = array();
				foreach($record->children() as $key => $value)
					$data[trim($key)] = trim($value);
				$alias = $data['alias'];
				if ($filever >= 1506)
					$data['title'] = htmlspecialchars_decode($data['title']);				
				$data['introtext'] = htmlspecialchars_decode($data['introtext']);
				$data['fulltext'] = htmlspecialchars_decode($data['fulltext']);
				
				$query = 'SELECT id, title'
					. ' FROM #__content'
					. ' WHERE alias = '. $db->Quote($alias)
					;
				$db->setQuery($query);
				$content = $db->loadObject();
						
				if (!$content || $import_content)			
				{ 
					$data['checked_out'] = 0;
					$data['checked_out_time'] = $nullDate;
	
					$table =& JTable::getInstance('content', 'eshTable');
					
					if (!$content)
					{ // new article
						$data['id'] = null;
						if ($keep_access > 0)
							$data['access'] = $keep_access;
						if ($keep_state < 2)
							// Force the state
							$data['state'] = $keep_state;
						//else keep the original state
						
						if (!$keep_attribs)
							$data['attribs'] = 'show_title=
	link_titles=\n
	show_intro=\n
	show_section=\n
	link_section=\n
	show_category=\n
	link_category=\n
	show_vote=\n
	show_author=\n
	show_create_date=\n
	show_modify_date=\n
	show_pdf_icon=\n
	show_print_icon=\n
	show_email_icon=\n
	language=\n
	keyref=\n
	readmore=';
						
						if (!$keep_metadata)
						{
							$data['metadata'] = 'robots=
	author=';
							$data['metakey'] = '';
							$data['metadesc'] = '';
							
						}
					}
					else // article already exists
					{
						$data['id'] = $content->id;
						$table->load($data['id']);
	
						if ($keep_access > 0)
							// don't modify the access level
							$data['access'] = null;
						
						if ($keep_state != 0)  
							// don't modify the state
							$data['state'] = null;
						//else keep the original state		
	
						if (!$keep_author) 
						{
							$data['created'] = null;
							$data['created_by'] = null; 
							$data['created_by_alias'] = null; 				
							$data['modified'] = $now; 
							$data['modified_by'] = $user_id; 
							$data['version'] = $table->version + 1; 
						}							
						else
						{
							// keep the original author
							if (isset($users_id[$data['created_by']]))
								$data['created_by'] = $users_id[$data['created_by']];
							else 
								$data['created_by'] = $users_id['admin'];
							if (isset($users_id[$data['modified_by']]))
								$data['modified_by'] = $users_id[$data['modified_by']];
							else
								$data['modified_by'] = $users_id['admin'];
						}
	
						if (!$keep_attribs)
							$data['attribs'] = null;
						
						if (!$keep_metadata)
						{
							$data['metadata'] = null;
							$data['metakey'] = null;
							$data['metadesc'] = null;
						}
					}
				
					// keep category
					if ($keep_category)
					{
						// keep category
						if (!isset($data['sectionid']) && !isset($data['catid']))
						{
							// uncategorised
						}
						else if ($attributes->mapkeystotext == 'false')
						{
							// use section and category id
						}	
						else if (isset($categories_id[$data['sectionid'].'/'.$data['catid']]))
						{
							// category already loaded
							$data['catid'] = $categories_id[$data['sectionid'].'/'.$data['catid']];
							$data['sectionid'] = $sections_id[$data['sectionid']];
						}
						else if (isset($sections_id[$data['sectionid']]))
						{
							// section already loaded, load category
							$data['sectionid'] = $sections_id[$data['sectionid']];
							
							$query = 'SELECT id'
								. ' FROM #__categories'
								. ' WHERE alias = '. $db->Quote($data['catid'])
								. ' AND section = '. $data['sectionid']
								;
								
							$db->setQuery($query);
							$categories_id[$data['sectionid'].'/'.$data['catid']] = (int)$db->loadResult();
							$data['catid'] = $categories_id[$data['sectionid'].'/'.$data['catid']];
						}
						else
						{
							// load section and category
							$query = 'SELECT id'
								. ' FROM #__sections'
								. ' WHERE alias = '. $db->Quote($data['sectionid'])
								;
							$db->setQuery($query);
							$section_id = (int)$db->loadResult();
			
							if ($section_id > 0)
							{
								$sections_id[$data['sectionid']] = $section_id;
								$data['sectionid'] = $section_id;
								$query = 'SELECT id'
									. ' FROM #__categories'
									. ' WHERE alias = '. $db->Quote($data['catid'])
									. ' AND section = '. $data['sectionid']
									;
								$db->setQuery($query);
								$category_id = (int)$db->loadResult();
								if ($category_id > 0)
								{
									$categories_id[$data['sectionid'].'/'.$data['catid']] = $category_id;
									$data['catid'] = $category_id;
								}
								else
								{
									$data['sectionid'] = 0;
									$data['catid'] = 0;
								}
							}
							else
							{
								$data['sectionid'] = 0;
								$data['catid'] = 0;
							}
						}
					} 
					else if ($content)
					{
						// don't keep category and article already exists
						$data['sectionid'] = null; 
						$data['catid'] =null; 				
					}
					else
					{
						// don't keep category & article is new & Joomla!1.5
						// set uncategorised
						$data['sectionid'] = 0; 
						$data['catid'] = 0; 				
					}
								
					if ($keep_author)
					{
						if (isset($users_id[$data['created_by']]))
							$data['created_by'] = $users_id[$data['created_by']];
						else
						{
							$query = 'SELECT id'
								. ' FROM #__users'
								. ' WHERE username = '. $db->Quote($data['created_by'])
								;
							$db->setQuery($query);
							$userid = (int)$db->loadResult();
							if ($userid > 0)
							{
								$users_id[$data['created_by']] = $userid;
								$data['created_by'] = $userid;
							}
							else
								$data['created_by'] = $users_id['admin'];
						}
						if (isset($users_id[$data['modified_by']]))
							$data['modified_by'] = $users_id[$data['modified_by']];
						else
						{
							$query = 'SELECT id'
								. ' FROM #__users'
								. ' WHERE username = '. $db->Quote($data['modified_by'])
								;
							$db->setQuery($query);
							$userid = (int)$db->loadResult();
							if ($userid > 0)
							{
								$users_id[$data['modified_by']] = $userid;
								$data['modified_by'] = $user;
							}
							else
								$data['modified_by'] = $users_id['admin'];
						}
					}
					else if ($content)
					{
						$data['created'] = null;
						$data['created_by'] = null; 
						$data['created_by_alias'] = null; 				
						$data['modified'] = null; 
						$data['modified_by'] = null; 
						$data['version'] = null; 
					}
					else
					{
						$data['created'] = $now;
						$data['created_by'] = $users_id['admin']; 
						$data['created_by_alias'] = null; 				
						$data['modified'] = $nullDate; 
						$data['modified_by'] = null; 
						$data['version'] = 1; 
					}
	
					if (!$keep_frontpage)
						$data['frontpage'] = null;
					else if ($data['frontpage'] >= 1)
						$data['frontpage'] = 1;
					else
						$data['frontpage'] = 0;
									
					if ($table->save($data))
					{
						if ($keep_frontpage)
						{
							$query = "SELECT * FROM #__content_frontpage WHERE content_id = ".$table->id;
							$db->setQuery($query);
							$exists = $db->LoadResult();
							
							$query = "";
							if ($data['frontpage'] == 0)
							{
								if ($exists)
									$query = "DELETE FROM #__content_frontpage WHERE content_id = ".$table->id;
							}
							else
							{
								$frontpage++;
								if ($exists)
									$query = 'UPDATE #__content_frontpage SET ordering = '.$frontpage.' WHERE content_id = '.$table->id;
								else
									$query = 'INSERT INTO #__content_frontpage VALUES('.$table->id.','.$frontpage.');';
							}
							if ($query)
							{
								$db->setQuery($query);
								$db->query();
							}
						}
	
						if ($keep_rating && isset($data['rating_count']))
						{
							$rating = new stdClass();
							$rating->content_id = $table->id;
							$rating->rating_count = $data['rating_count'];
							$rating->rating_sum = $data['rating_sum'];
							$rating->lastip = $_SERVER['REMOTE_ADDR'];
							if (!$db->insertObject('#__content_rating', $rating))
								$db->updateObject('#__content_rating', $rating, 'content_id');
						}
						self::trace(true, $xmlrpc, $table->title, 'article', $msg);
					}
					else
						self::trace(false, $xmlrpc, $data['title'], 'article', $msg);
				}
			}
		}
		
		if ($import_images)
		{
			foreach($xml->img as $image)
			{ 
				$src = JPATH_SITE.DS.str_replace('/', DS, $image['src']); 
				$data = $image;
				if (!file_exists($src) || ($import_images == 2))
				{
					// many thx to Stefanos Tzigiannis
					$folder = dirname($src);
					if (!JFolder::exists($folder)) {
						if (JFolder::create($folder))
							self::trace(true, $xmlrpc, $folder, 'folder', $msg);
						else
						{
							self::trace(false, $xmlrpc, $folder, 'folder', $msg);
							break;
						}
					}
 					if (JFile::write($src, base64_decode($data)))
						self::trace(true, $xmlrpc, $image['src'], 'image', $msg);
					else
						self::trace(false, $xmlrpc, $image['src'], 'image', $msg);
				}
			}
		} 

		/*
		 * Import Weblinks
		 */
		foreach($xml->xpath("weblink") as $record)
		{
			$attributes = $record->attributes();
			$data = array();
			foreach($record->children() as $key => $value)
				$data[trim($key)] = trim($value);
			$alias = $data['alias'];
			if ($filever >= 1506)
				$data['title'] = htmlspecialchars_decode($data['title']);				
			$data['description'] = htmlspecialchars_decode($data['description']);
			// add fields not used
			$data['archived'] = 0;
			$data['approved'] = 1;
			
			$query = 'SELECT id, title'
				. ' FROM #__weblinks'
				. ' WHERE alias = '. $db->Quote($alias)
				;
			$db->setQuery($query);
			$weblink = $db->loadObject();
					
			if (!$weblink || $import_weblinks)			
			{ 
				$data['checked_out'] = 0;
				$data['checked_out_time'] = $nullDate;

				$table =& JTable::getInstance('weblink', 'eshTable');
				
				if (!$weblink)
				{ // new weblink
					$data['id'] = null;
					if ($keep_state < 2)
						// Force the state
						$data['published'] = $keep_state;
					//else keep the original state
					
					if (!$keep_attribs)
						$data['attribs'] = 'target=';
				}
				else // weblink already exists
				{
					$data['id'] = $weblink->id;
					$table->load($data['id']);

					if ($keep_state != 0)  
						// don't modify the state
						$data['published'] = null;
					//else keep the original state		

					if (!$keep_attribs)
						$data['params'] = null;
				}
			
				if ($attributes->mapkeystotext == 'false')
				{
					// use section and category id
				}	
				else if (isset($categories_id['com_weblinks/'.$data['catid']]))
				{
					// category already loaded
					$data['catid'] = $categories_id['com_weblinks/'.$data['catid']];
				}
				else
				{
					// load category
					$query = 'SELECT id'
						. ' FROM #__categories'
						. ' WHERE alias = '. $db->Quote($data['catid'])
						. ' AND section = '. $db->Quote('com_weblinks')
						;
					$db->setQuery($query);
					$category_id = (int)$db->loadResult();
					if ($category_id > 0)
					{
						$categories_id['com_weblinks/'.$data['catid']] = $category_id;
						$data['catid'] = $category_id;
					}
					else
					{
						self::trace(false, $xmlrpc, $data['title'], 'weblinkcat', $msg);
						continue;
					}
				}
							
				$table->bind($data);
				if ($table->store())
					self::trace(true, $xmlrpc, $table->title, 'weblink', $msg);
				else
					self::trace(false, $xmlrpc, $data['title'], 'weblink', $msg);
			}
		}

		if ($xmlrpc === true)
			return new xmlrpcval($msg, "array");
	}	
	
	private static function trace($ok, $xmlrpc, $title, $type, &$msg)
	{
		$app =& JFactory::getApplication('administrator');
		
		if ($xmlrpc === true)
			$msg[] = new xmlrpcval(
				array(
					"code" => new xmlrpcval(self::$codes[$type.($ok?'ok':'notok')], 'int'),
					"string" => new xmlrpcval($title, 'string')
				), "struct"
		  	);
		else
			$app->enqueueMessage(
				JText::sprintf(self::$messages[$type.($ok?'ok':'notok')], $title), 
				($ok)?'message':'notice'
				);
	}
}
?>
