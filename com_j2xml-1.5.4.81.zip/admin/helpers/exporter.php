<?php
/**
 * @version		1.5.4.78 administrator/components/com_j2xml/helpers/exporter.php
 * @package		J2XML
 * @subpackage	com_j2xml
 * @since		1.5.2.14
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

//Import filesystem libraries.
jimport('joomla.filesystem.file');

class J2XMLExporter
{
	static $image_match_string = '/<img.*?src="([^"]*)".*?[^>]*>/s';
	// images/stories is path of the images of the sections and categories hard coded in the file \libraries\joomla\html\html\list.php at the line 52
	static $image_path = "images/stories";
	
	/*
	 * Export content articles, images, section and categories
	 * @return 		xml string
	 * @since		1.5.2.14
	 */
	static function contents($ids, $export_images, $export_categories, $export_users, &$images)
	{		
		$xml = '';		

		$section =& JTable::getInstance('section', 'eshTable');
		$sections = array();
		
		$category =& JTable::getInstance('category', 'eshTable');
		$categories = array();

		$user =& JTable::getInstance('user', 'eshTable');
		$users = array();
		
		foreach($ids as $id)
		{
			$item =& JTable::getInstance('content', 'eshTable');
			$item->load($id);

			if ($export_users)
			{
				if (($item->created_by != 62) 
				&& (!array_key_exists($item->created_by, $users)))
				{
					$user->load($item->created_by);
					$users[$item->created_by] = $user->toXML(true);
				}
				if (($item->modified_by != 62) 
					&& ($item->modified_by != 0) 
					&& (!array_key_exists($item->modified_by, $users)))
				{
					$user->load($item->modified_by);
					$users[$item->modified_by] = $user->toXML(true);
				}
			}	

			if ($export_categories && ($item->sectionid > 0))
			{
				if (!array_key_exists($item->sectionid, $sections))
				{
					$section->load($item->sectionid);
					$sections[$item->sectionid] = $section->toXML(true);
					if ($export_images)
					{
						if ($section->image)
						{
							$image = self::$image_path."/".$section->image;
							$file_path = JPATH_SITE.DS.str_replace("/", DS, $image);
							if (!array_key_exists($image, $images) && JFile::exists($file_path))
								$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
									."\t\t\t".base64_encode(file_get_contents($file_path))
									."\t\t</img>\n";
						}
						$text = html_entity_decode($section->description);
						$image = preg_match_all(self::$image_match_string,$text,$matches,PREG_PATTERN_ORDER);
						if (count($matches[1]) > 0)
						{
							for ($i = 0; $i < count($matches[1]); $i++)
							{
								$image = $matches[1][$i];						
								$file_path = JPATH_SITE.DS.str_replace("/", DS, $matches[1][$i]);
								if (!array_key_exists($image, $images) && JFile::exists($file_path))
									$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
										."\t\t\t".base64_encode(file_get_contents($file_path))
										."\t\t</img>\n";
							}
						}
					}
				}
				
				if (!array_key_exists($item->catid, $categories))
				{
					$category->load($item->catid);
					$categories[$item->catid] = $category->toXML(true);
					$text = html_entity_decode($category->description);
					$image = preg_match_all(self::$image_match_string,$text,$matches,PREG_PATTERN_ORDER);
					if (count($matches[1]) > 0)
					{
						for ($i = 0; $i < count($matches[1]); $i++)
						{
							$image = $matches[1][$i];						
							$file_path = JPATH_SITE.DS.str_replace("/", DS, $matches[1][$i]);
							if (!array_key_exists($image, $images) && JFile::exists($file_path))
								$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
									."\t\t\t".base64_encode(file_get_contents($file_path))
									."\t\t</img>\n";
						}
					}
					if (($export_images) && ($category->image))
					{
						$image = self::$image_path."/".$category->image;
						$file_path = JPATH_SITE.DS.str_replace("/", DS, $image);
						if (!array_key_exists($image, $images) && JFile::exists($file_path))
							$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
								."\t\t\t".base64_encode(file_get_contents($file_path))
								."\t\t</img>\n";
					}
				}
			}	
			if ($export_images)
			{
				$text = $item->introtext.$item->fulltext;
				$image = preg_match_all(self::$image_match_string,$text,$matches,PREG_PATTERN_ORDER);
				if (count($matches[1]) > 0)
				{
					for ($i = 0; $i < count($matches[1]); $i++)
					{
						$image = $matches[1][$i];						
						$file_path = JPATH_SITE.DS.str_replace("/", DS, $matches[1][$i]);
						if (!array_key_exists($image, $images) && JFile::exists($file_path))
							$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
								."\t\t\t".base64_encode(file_get_contents($file_path))
								."\t\t</img>\n";
					}
				}
			}
			$xml .= $item->toXML(true);
		}
		foreach($sections as $section)
			$xml .= $section;
		foreach($categories as $category)
			$xml .= $category;
		foreach($users as $user)
			$xml .= $user;
		
		return $xml;
	}

	/*
	 * Export weblinks
	 * @return 		xml string
	 * @since		1.5.3beta3.38
	 */
	static function weblinks($ids, $export_images, &$images)
	{		
		$xml = '';

		$category =& JTable::getInstance('category', 'eshTable');
		$categories = array();
		
		foreach($ids as $id)
		{
			$item =& JTable::getInstance('weblink', 'eshTable');
			$item->load($id);

			if (!array_key_exists($item->catid, $categories))
			{
				$category->load($item->catid);
				$categories[$item->catid] = $category->toXML(true);
				if ($export_images)
				{
					if ($category->image)
					{
						$image = self::$image_path."/".$category->image;
						$file_path = JPATH_SITE.DS.str_replace("/", DS, $image);
						if (!array_key_exists($image, $images) && JFile::exists($file_path))
							$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
								."\t\t\t".base64_encode(file_get_contents($file_path))
								."\t\t</img>\n";
					}
					$text = html_entity_decode($category->description);
					$image = preg_match_all(self::$image_match_string,$text,$matches,PREG_PATTERN_ORDER);
					if (count($matches[1]) > 0)
					{
						for ($i = 0; $i < count($matches[1]); $i++)
						{
							$image = $matches[1][$i];						
							$file_path = JPATH_SITE.DS.str_replace("/", DS, $matches[1][$i]);
							if (!array_key_exists($image, $images) && JFile::exists($file_path))
								$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
									."\t\t\t".base64_encode(file_get_contents($file_path))
									."\t\t</img>\n";
						}
					}
				}			
			}
			$xml .= $item->toXML(true);
		}
		foreach($categories as $category)
			$xml .= $category;
	
		return $xml;
	}


	/*
	 * Export users
	 * @return 		xml string
	 * @since		1.5.3beta4.39
	 */
	static function users($ids)
	{		
		$xml = '';
		
		foreach($ids as $id)
		{
			$item =& JTable::getInstance('user', 'eshTable');
			$item->load($id);

			$xml .= $item->toXML(true);
		}
		
		return $xml;
	}

	/*
	 * Export categories
	 * @return 		xml string
	 * @since		1.5.3beta5.43
	 */
	static function categories($ids, $export_images, $export_sections, $export_users, &$images, $export_contents = true)
	{		
		$xml = '';
		$sections = array();

		foreach($ids as $id)
		{
			$item =& JTable::getInstance('category', 'eshTable');
			$item->load($id);
			$xml .= $item->toXML(true);

			/* export section */
			if ($export_sections && ($item->section > 0))
			{
				if (!array_key_exists($item->section, $sections))
				{
					$section =& JTable::getInstance('section', 'eshTable');
					$section->load($item->section);
					$sections[$item->section] = $section->toXML(true);
					if ($export_images)
					{
						if ($section->image)
						{
							$image = self::$image_path."/".$section->image;
							$file_path = JPATH_SITE.DS.str_replace("/", DS, $image);
							if (!array_key_exists($image, $images) && JFile::exists($file_path))
								$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
									."\t\t\t".base64_encode(file_get_contents($file_path))
									."\t\t</img>\n";
						}
						$text = html_entity_decode($section->description);
						$image = preg_match_all(self::$image_match_string,$text,$matches,PREG_PATTERN_ORDER);
						if (count($matches[1]) > 0)
						{
							for ($i = 0; $i < count($matches[1]); $i++)
							{
								$image = $matches[1][$i];						
								$file_path = JPATH_SITE.DS.str_replace("/", DS, $matches[1][$i]);
								if (!array_key_exists($image, $images) && JFile::exists($file_path))
									$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
										."\t\t\t".base64_encode(file_get_contents($file_path))
										."\t\t</img>\n";
							}
						}
					}					
				}
			}	
			if ($export_images)
			{
				if ($item->image)
				{
					$image = self::$image_path."/".$item->image;
					$file_path = JPATH_SITE.DS.str_replace("/", DS, $image);
					if (!array_key_exists($image, $images) && JFile::exists($file_path))
						$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
							."\t\t\t".base64_encode(file_get_contents($file_path))
							."\t\t</img>\n";
				}
				$text = html_entity_decode($item->description);
				$image = preg_match_all(self::$image_match_string,$text,$matches,PREG_PATTERN_ORDER);
				if (count($matches[1]) > 0)
				{
					for ($i = 0; $i < count($matches[1]); $i++)
					{
						$image = $matches[1][$i];						
						$file_path = JPATH_SITE.DS.str_replace("/", DS, $matches[1][$i]);
						if (!array_key_exists($image, $images) && JFile::exists($file_path))
							$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
								."\t\t\t".base64_encode(file_get_contents($file_path))
								."\t\t</img>\n";
					}
				}
			}
			if ($export_contents === TRUE)
			{
				/* export contents */
				$db =& JFactory::getDBO();
				$query = "SELECT `id` FROM `#__content` WHERE `catid` = $id";
				$db->setQuery($query);
				$content_ids = $db->loadResultArray();
				if (isset($content_ids))
					$xml .= 
						self::contents(
							$content_ids, 
							$export_images, 
							0, 
							$export_users,
							$images
						);
			}
		}
		foreach($sections as $section)
			$xml .= $section;
		
		return $xml;
	}

	/*
	 * Export sections
	 * @return 		xml string
	 * @since		1.5.3beta5.43
	 */
	static function sections($ids, $export_images, $export_users, &$images, $export_contents = true)
	{		
		$xml = '';

		foreach($ids as $id)
		{
			$item =& JTable::getInstance('section', 'eshTable');
			$item->load($id);
			$xml .= $item->toXML(true);
			
			/* export categories */
			$db =& JFactory::getDBO();
			$query = "SELECT `id` FROM `#__categories` WHERE `section` = $id";
			$db->setQuery($query);
			$cat_ids = $db->loadResultArray();
			if (isset($cat_ids))
				$xml .= 
					self::categories(
						$cat_ids, 
						$export_images,
						0, 
						$export_users,
						$images,
						$export_contents
					);
			if ($export_images)
			{
				if ($item->image)
				{
					$image = self::$image_path."/".$item->image;
					$file_path = JPATH_SITE.DS.str_replace("/", DS, $image);
					if (!array_key_exists($image, $images) && JFile::exists($file_path))
						$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
							."\t\t\t".base64_encode(file_get_contents($file_path))
							."\t\t</img>\n";
				}
				$text = html_entity_decode($item->description);
				$image = preg_match_all(self::$image_match_string,$text,$matches,PREG_PATTERN_ORDER);
				if (count($matches[1]) > 0)
				{
					for ($i = 0; $i < count($matches[1]); $i++)
					{
						$image = $matches[1][$i];						
						$file_path = JPATH_SITE.DS.str_replace("/", DS, $matches[1][$i]);
						if (!array_key_exists($image, $images) && JFile::exists($file_path))
							$images[$image] = "\t\t<img src=\"".htmlentities($image)."\">"
								."\t\t\t".base64_encode(file_get_contents($file_path))
								."\t\t</img>\n";
					}
				}
			}
		}
		return $xml;
	}

	static function export($xml, $debug, $export_gzip, $structure=false)
	{
		if ($debug > 0)
		{
			$app = JFactory::getApplication();
			$data = ob_get_contents();
			if ($data)
			{	
				$app->enqueueMessage(JText::_('COM_J2XML_MSG_ERROR_EXPORT'), 'error');
					$app->enqueueMessage($data, 'error');
				return false;
			}
		}
		ob_clean();
			
		$version = explode(".", J2XMLVersion::$DOCVERSION);
		$xmlVersionNumber = $version[0].$version[1].substr('0'.$version[2], strlen($version[2])-1);
		
		$data = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
		$data .= J2XMLVersion::$DOCTYPE."\n";
		$data .= "<j2xml version=\"".J2XMLVersion::$DOCVERSION."\" ".($structure ? 'structure="true"' : '').">\n";
		$data .= $xml; 
		$data .= "</j2xml>";
		// modify the MIME type
		$document =& JFactory::getDocument();
		if ($export_gzip)
		{
			$document->setMimeEncoding('application/gzip-compressed', true);
			JResponse::setHeader('Content-disposition', 'attachment; filename="j2xml'.$xmlVersionNumber.date('YmdHis').'.gz"', true);
			$data = gzencode($data, 9);
		}
		else 
		{
			$document->setMimeEncoding('application/xml', true);
			JResponse::setHeader('Content-disposition', 'attachment; filename="j2xml'.$xmlVersionNumber.date('YmdHis').'.xml"', true);
		}
		echo $data;
		return true;
	}
}