<?php
/**
 * @package		J2XML
 * @subpackage	com_j2xml
 * @version		1.5.4
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010-2015 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
?>

----------------------- 1.5.4.81 Release  [7-June-2015] -----------------------

10-September-2013
  # category/section alias (build 80)

5-September-2013
  # category/section alias (build 79)

--------------------- 1.5.4.78 Release [3-September-2013] ---------------------

3-September-2013
  # category/section alias (build 78)
  + send custom (build 78)

26-August-2013
  # send sections (build 77)

24-August-2013
  # send (build 76)

-------------------------- 1.5.4.74  [14-June-2013] --------------------------

14-June-2013
  # export access field (build 74)

--------------------------- 1.5.4.73 [6-June-2013] ---------------------------

6-June-2013
  # sanitize XML (build 73)

-------------------------- 1.5.4.72 [19-April-2013] --------------------------

19-April-2013
  + send to Joomla! 2.5 (build 72)

10-April-2013
  + export structure (build 71)
  + export users (build 71)
  + export content (build 71)
  
--------------------------- 1.5.3.60 [18-May-2011] ---------------------------

18-May-2011
  # [8] UTF-8 data sanitizer

---------------------------- 1.5.3.59 [2-May-2011] ---------------------------

2-May-2011
  + italian language
  ^ changed XML file format (version="1.5.6")
  # category/section alias

5-April-2011
  + import from local file

4-April-2011
  # [5] Control Panel blank screen after install

--------------------------- 1.5.3.49 [3-March-2011] --------------------------

3-March-2011
  # [2] don't import categories without section
  
2-March-2011
  # [1] export sections from category manager

------------------------- 1.5.3.48 [23-February-2011] ------------------------

23-February-2011
  + added FTP support to import images
  - removed live update authentication
  # fixed default params
  # fixed send users  
  # fixed send weblinks

19-February-2011
  + added UTF-8 data sanitizer
  # fixed import frontpage
  # fixed website management
  # fixed export articles without alias
  # fixed export sections without alias
  # fixed export categories without alias

----------------------- 1.5.3-rc1.45 [10-February-2011] ----------------------

10-February-2011
  + send content to J!1.6 web site
  + added doctype to xml file
  + plg_system_limit500 1.5.3-rc1.1 select items 500 at a time
  ^ plg_system_j2xml 1.5.3-rc1.9
  ^ plg_xmlrpc_j2xml 1.5.3-rc1.6
  ^ export empty categories
  ^ export empty sections
  # fixed bug: export images from sections and categories description
  # fixed some minor bugs
  - removed export categories option

---------------------- 1.5.3beta4.41 [4-February-2011] ----------------------

4-February-2011
  + export/import/send users (plg_system_j2xml 1.5.3.8)
  + xml file format specification (j2xml.dtd)
  ^ changed XML file format (version="1.5.5")
  # import ratings
  # import frontpage
  # import users
  # import categories
  # import weblink categories  

---------------------- 1.5.3beta3.38 [2-February-2011] ----------------------

2-February-2011
  + export/import/send weblinks (plg_system_j2xml 1.5.3.7)
  ^ changed XML file format (version="1.5.4") added weblink items
  # fixed export articles from category manager
  # fixed export articles from section manager
  # fixed minor bugs

---------------------- 1.5.3beta2.37 [31-January-2011] ----------------------

31-January-2011
  # fixed bug: default "keep" options not recognized

30-January-2011
  $ fixed english file

---------------------- 1.5.3beta2.35 [30-January-2011] ----------------------

30-January-2011
  ^ changed the method of identification of file format (by extension)
  # fixed bug in import of the name and description of the categories (UTF-8 data). 

---------------------- 1.5.3beta2.34 [27-January-2011] ----------------------

27-January-2011
  # fixed plg_system_j2xml 1.5.3.6
  # fixed plg_xmlrpc_j2xml 1.5.3.3

24-January-2011
  ^ Changed XML file format (version="1.5.3")
  	content-&gt;introtext, content-&gt;fulltext, sections-&gt;description and
  	categories-&gt;description use HTML entities

21-January-2011
  + added support to gzip format
  $ fixed english file

20-January-2011
  + added trashed content J!1.5 export (plg_system_j2xml 1.5.3.5)
  $ fixed english file

19-January-2011
  + content - rating import/export

18-January-2011
  ^ redrawed toolbars
  + added "save&amp;new" in "website edit" toolbar 
  # fixed redirect after website saving
  # fixed importing categories
  $ fixed english file

12-January-2011
  + Added state pane in control panel
  ^ import function: set primary key of the articles = alias

11-January-2011
  + Added welcome pane in control panel

11-January-2011
  + Added control panel
  ^ Automatic plugin uninstall
  ^ Changed Send button in system plugin 1.5.3.3

11-January-2011
  + Added website manager

9-January-2011
  + Added rpcxml plugin 1.5.3.1
  + Added send function
  + Added send button in system plugin
  # Minor bugs fixed

----------------------- 1.5.2.14 Build [29-December-2010] --------------------

29-December-2010
  + Added system plugin 1.5.0.1
  + Added section export 
  + Added category export 

20-December-2010
  + Added file version verification

----------------------- 1.5.1.13 Build [15-December-2010] --------------------

15-December-2010
  # fixed import function. Now you can preserve categories, created by user 
    and modified by user even if they were not exported to the xml file 
  # fixed autoupdate function with registered user
  ^ use mapkeystotext="false" in content record to use id instead of alias

--------------------- 1.5.1.12 Release [23-November-2010] --------------------

12-November-2010
  # fixed importer 1.5.0 call bug 

-------------------- 1.5.1.11 Release [27-September-2010] --------------------

27-September-2010
  # fixed minor bug in main view

--------------------- 1.5.1.10 Build [23-September-2010] ---------------------

23-September-2010
  + added update function

----------------------- 1.5.1.9 Build [12-August-2010] -----------------------

12-August-2010
  ^ changed main view. Changed field published, added field front page
  $ added the description of the frontpage option
  - deleted unused folders and files

----------------------- 1.5.1.8 Build [11-August-2010] -----------------------

11-August-2010
  + preserve frontpage articles

----------------------- 1.5.1.7 Build [11-August-2010] -----------------------

11-August-2010
  + Added update function
  $ Language bug fixed

---------------------- 1.5.1.6  Release [8-August-2010] ----------------------

8-August-2010
  + Added the ability to import/export the sections and categories that
    the articles are assigned to
  + Added the ability to import/export users who created or modified
    the articles
  ^ Changed XML file format (version="1.5.1")
  + Removed French translation

----------------------- 1.5.0.5  Build [4-August-2010] -----------------------

4-August-2010
  + Added Help file. 
  ^ Merged preserve state and preserve publishing options. 
  # Fixed bug, create images folder if not exists.

------------------------ 1.5.0.4  Build [20-July-2010] -----------------------

20-July-2010
  + Added Error handling in the Import function
  # Fixed bug where selecting a category 

------------------------ 1.5.0.3  Build [28-June-2010] -----------------------

28-June-2010
  + Added French translation by Alain Vallette (Thanks Alain!)

------------------------ 1.5.0.2  Build [10-June-2010] -----------------------

10-June-2010
  # use of time given to the web server in the import function 

------------------------ 1.5.0.1  Release [6-June-2010] ----------------------

6-June-2010
  + Initial Release

Legend:

* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note
