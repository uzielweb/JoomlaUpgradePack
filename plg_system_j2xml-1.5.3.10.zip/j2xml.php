<?php
/**
 * @version		1.5.3.10 plugins/system/j2xml.php
 * @package		J2XML
 * @subpackage	plg_system_j2xml
 * @since		1.5.2
 *
 * @author		Helios Ciancio <info@eshiol.it>
 * @link		http://www.eshiol.it
 * @copyright	Copyright (C) 2010-2011 Helios Ciancio. All Rights Reserved
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License 
 * or other free or open source software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access.');

jimport('joomla.plugin.plugin');
jimport('joomla.application.component.helper');
jimport('joomla.filesystem.file');

class plgSystemJ2XML extends JPlugin
{
	var $params = null;
	/**
	 * CONSTRUCTOR
	 * @param object $subject The object to observe
	 * @param object $params  The object that holds the plugin parameters
	 * @since 1.5
	 */
	function __construct(&$subject, $params)
	{
		$this->params = $params;
		parent::__construct($subject, $params);
		JPlugin::loadLanguage('com_j2xml', JPATH_ADMINISTRATOR);
	}

	/**
	 * Method is called by index.php and administrator/index.php
	 *
	 * @access	public
	 */
	public function onAfterDispatch()
	{
		$app =& JFactory::getApplication();
		if($app->getName() != 'administrator') {
			return true;
		}

		$enabled = JComponentHelper::getComponent('com_j2xml', true);
		if (!$enabled->enabled) 
			return true; 

		if (!JFile::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_j2xml'.DS.'buttons'.DS.'standard2.php'))
			return true; 
		if (!JFile::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_j2xml'.DS.'buttons'.DS.'send.php'))
			return true; 
						
		$option = JRequest::getVar('option');
		$section = JRequest::getVar('section');
		$task = JRequest::getVar('task');
		$layout = JRequest::getVar('layout');
		$toolbar =& JToolBar::getInstance('toolbar');
		$toolbar->addButtonPath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_j2xml'.DS.'buttons');
		$toolbar->loadButtonType('Standard2', true);
		$doc =& JFactory::getDocument();
		$icon_32_send = " .icon-32-j2xml_send {background:url(components/com_j2xml/assets/images/toolbar/icon-32-send.png) no-repeat; }"; 
		$doc->addStyleDeclaration($icon_32_send);
		$icon_32_export = " .icon-32-j2xml_export {background:url(components/com_j2xml/assets/images/toolbar/icon-32-export.png) no-repeat; }"; 
		$doc->addStyleDeclaration($icon_32_export);
		if (($option == 'com_content') && ($task == '') && ($layout == ''))
		{
			$toolbar->prependButton('Send', 'j2xml_send', 'COM_J2XML_BUTTON_SEND', 'j2xml.content.send');
			$toolbar->prependButton('Standard2', 'j2xml_export', 'COM_J2XML_BUTTON_EXPORT', 'j2xml.content.export');
		}
		else if (($option == 'com_sections') && ($task == ''))
		{
			$toolbar->prependButton('Send', 'j2xml_send', 'COM_J2XML_BUTTON_SEND', 'j2xml.sections.send');
			$toolbar->prependButton('Standard2', 'j2xml_export', 'COM_J2XML_BUTTON_EXPORT', 'j2xml.sections.export');
		}
		else if (($option == 'com_categories') && ($task == ''))
		{
			if ($section == 'com_content')
			{
				$toolbar->prependButton('Send', 'j2xml_send', 'COM_J2XML_BUTTON_SEND', 'j2xml.categories.send');
				$toolbar->prependButton('Standard2', 'j2xml_export', 'COM_J2XML_BUTTON_EXPORT', 'j2xml.categories.export');
			}
		}
		else if ($option == 'com_trash') 
		{
			$task	= JRequest::getCmd('task', 'viewMenu');
			$return	= JRequest::getCmd('return', 'viewContent', 'post');
			if (($task == 'viewContent') || ($return == 'viewContent') && ($task == 'cancel'))
			{
				$toolbar->prependButton('Send', 'j2xml_send', 'COM_J2XML_BUTTON_SEND', 'j2xml.content.send');
				$toolbar->prependButton('Standard2', 'j2xml_export', 'COM_J2XML_BUTTON_EXPORT', 'j2xml.content.export');
			}
		}
		else if (($option == 'com_weblinks') && ($layout == ''))
		{
			$toolbar->prependButton('Send', 'j2xml_send', 'COM_J2XML_BUTTON_SEND', 'j2xml.weblinks.send');
			$toolbar->prependButton('Standard2', 'j2xml_export', 'COM_J2XML_BUTTON_EXPORT', 'j2xml.weblinks.export');
		}
		else if (($option == 'com_users') && ($layout == ''))
		{
			$toolbar->prependButton('Send', 'j2xml_send', 'COM_J2XML_BUTTON_SEND', 'j2xml.users.send');
			$toolbar->prependButton('Standard2', 'j2xml_export', 'COM_J2XML_BUTTON_EXPORT', 'j2xml.users.export');
		}
		return true;
	}
}
?>