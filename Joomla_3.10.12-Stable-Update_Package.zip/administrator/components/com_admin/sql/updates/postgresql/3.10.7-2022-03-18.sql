ALTER TABLE "#__users" ADD COLUMN "authProvider" varchar(100) DEFAULT '' NOT NULL;
